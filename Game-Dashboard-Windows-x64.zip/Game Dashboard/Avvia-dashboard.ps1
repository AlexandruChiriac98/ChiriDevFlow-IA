param(
    [switch]$SenzaBrowser,
    [switch]$Arresta,
    [ValidateRange(1024, 65530)]
    [int]$Porta = 8907
)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$router = Join-Path $root 'public\index.php'
$instance = $root.TrimEnd('\').Replace('\', '/')
$dashboardUrl = $null
$running = $null
$process = $null

function Get-DashboardHealth([string]$Url) {
    try {
        Invoke-RestMethod -Uri "$Url/health" -Method Get -TimeoutSec 1
    } catch {
        $null
    }
}

function Test-PortBusy([int]$Port) {
    $socket = New-Object System.Net.Sockets.TcpClient
    try {
        $connection = $socket.ConnectAsync('127.0.0.1', $Port)
        $connection.Wait(300) -and $socket.Connected
    } catch {
        $false
    } finally {
        $socket.Dispose()
    }
}

try {
    $freePort = $null
    foreach ($candidate in $Porta..($Porta + 4)) {
        if (!(Test-PortBusy $candidate)) {
            if ($null -eq $freePort) { $freePort = $candidate }
            continue
        }
        $url = "http://127.0.0.1:$candidate"
        $health = Get-DashboardHealth $url
        if ($health.app -eq 'ilchiridev-game-workflow' -and $health.instance -eq $instance) {
            $dashboardUrl = $url
            $running = $health
            break
        }
    }

    if ($Arresta) {
        if ($running) {
            $serverId = [int]$running.pid
            $server = Get-CimInstance Win32_Process -Filter "ProcessId=$serverId"
            $address = $dashboardUrl.Replace('http://', '')
            if ($server -and $server.CommandLine -and $server.CommandLine.Contains($router) -and $server.CommandLine.Contains("-S $address")) {
                Stop-Process -Id $serverId
                Write-Output 'Dashboard arrestata.'
            } else {
                throw 'La dashboard risulta avviata da un altro processo. Chiudi il terminale che la sta eseguendo.'
            }
        }
        exit 0
    }

    if (!$running) {
        if ($null -eq $freePort) {
            throw "Le porte locali da $Porta a $($Porta + 4) sono occupate."
        }
        $phpInPath = Get-Command php.exe -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
        $mamp = Get-ChildItem -LiteralPath 'C:\MAMP\bin\php' -Directory -ErrorAction SilentlyContinue |
            Sort-Object { try { [version]($_.Name -replace '^php', '') } catch { [version]'0.0' } } -Descending |
            ForEach-Object { Join-Path $_.FullName 'php.exe' }
        $bundledDir = Join-Path $root 'runtime\php'
        $bundledPhp = Join-Path $bundledDir 'php.exe'
        $php = @($env:GAME_WORKFLOW_PHP, $bundledPhp, $phpInPath.Source) + @($mamp) + @('C:\xampp\php\php.exe')
        $php = $php | Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Leaf) } | Select-Object -First 1
        if (!$php) {
            throw 'PHP 8.2 o successivo richiesto. Aggiungi php.exe al PATH o indica il suo percorso in GAME_WORKFLOW_PHP.'
        }
        $phpOptions = ''
        if ((Resolve-Path -LiteralPath $php).Path -eq $bundledPhp) {
            $ini = Join-Path $bundledDir 'php.ini'
            $extensions = Join-Path $bundledDir 'ext'
            if (!(Test-Path -LiteralPath $ini -PathType Leaf)) { throw 'PHP portatile incompleto. Estrai di nuovo tutto lo ZIP.' }
            $phpOptions = '-c "{0}" -d "extension_dir={1}" ' -f $ini, $extensions
        }

        $runtime = Join-Path $root 'var\runtime'
        New-Item -ItemType Directory -Path $runtime -Force | Out-Null
        $log = Join-Path $runtime "server-$freePort.log"
        $dashboardUrl = "http://127.0.0.1:$freePort"
        $public = Join-Path $root 'public'
        $arguments = $phpOptions + ('-d upload_max_filesize=20M -d post_max_size=24M -S 127.0.0.1:{0} -t "{1}" "{2}"' -f $freePort, $public, $router)
        $start = @{
            FilePath = $php
            ArgumentList = $arguments
            WorkingDirectory = $root
            WindowStyle = 'Hidden'
            PassThru = $true
            RedirectStandardOutput = Join-Path $runtime "server-$freePort-output.log"
            RedirectStandardError = $log
        }
        $process = Start-Process @start
        for ($attempt = 0; $attempt -lt 30; $attempt++) {
            if ($process.HasExited) { break }
            if (Test-PortBusy $freePort) {
                $health = Get-DashboardHealth $dashboardUrl
                if ($health.app -eq 'ilchiridev-game-workflow' -and $health.instance -eq $instance) {
                    $running = $health
                    break
                }
            }
            Start-Sleep -Milliseconds 150
        }
        if (!$running) {
            if ($phpOptions) {
                throw "PHP portatile non si e avviato. Controlla il runtime Microsoft Visual C++ v14 x64 indicato nel README. Registro: $log"
            }
            throw "Il server PHP non si e avviato. Registro: $log"
        }
    }

    try {
        $state = Invoke-RestMethod -Uri "$dashboardUrl/api?action=state" -Method Get -TimeoutSec 4
        if (!$state.sections) { throw 'Risposta inattesa.' }
    } catch {
        throw 'Il server risponde ma il registro non si apre. Controlla PDO SQLite e i permessi della cartella dati.'
    }

    if (!$SenzaBrowser) { Start-Process $dashboardUrl }
    Write-Output "Game Dashboard: $dashboardUrl"
} catch {
    if ($process -and !$process.HasExited) {
        Stop-Process -InputObject $process -ErrorAction SilentlyContinue
    }
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
