@echo off
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Avvia-dashboard.ps1" %*
if errorlevel 1 (
    pause
    exit /b 1
)
