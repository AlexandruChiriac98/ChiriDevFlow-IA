@echo off
call "%~dp0Avvia-dashboard.cmd" -Arresta %*
exit /b %errorlevel%
