const csrf = document.querySelector('meta[name="workflow-csrf"]').content;

export async function api(action, params = {}, data) {
    const url = new URL('/api', location.origin);
    for (const [key, val] of Object.entries({ action, ...params })) url.searchParams.set(key, val);
    const options = { headers: { Accept: 'application/json' } };
    if (data !== undefined) {
        options.method = 'POST';
        options.headers['X-Workflow-CSRF'] = csrf;
        if (data instanceof FormData) {
            options.body = data;
        } else {
            options.headers['Content-Type'] = 'application/json';
            options.body = JSON.stringify(data);
        }
    }
    const response = await fetch(url, options);
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Operazione non riuscita.');
    return result;
}

export const icon = name => `<svg class="icon" aria-hidden="true"><use href="#i-${name}"/></svg>`;
export const h = value => String(value ?? '').replace(/[&<>"']/g, char =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
export const gameUrl = (id, section = 'overview', selection) => `#game/${id}/${section}${selection ? `/${selection}` : ''}`;
export function entryFilterSuffix({ approval, search }) {
    const params = new URLSearchParams();
    if (approval) params.set('approval', approval);
    if (search.trim()) params.set('q', search.trim());
    return params.size ? '?' + params.toString() : '';
}
export const fileUrl = (project, entry, preview = false) =>
    `/api?action=file&project=${Number(project)}&id=${Number(entry)}${preview ? '&mode=preview' : ''}`;
export const statusTone = status => ({
    'In corso': 'amber', 'Da rivedere': 'red', 'Completato': 'green',
    'Concept / Produzione': 'red', 'Prototipo': 'amber', 'Briefing': 'blue', 'Playtest': 'amber', 'Pubblicato': 'green'
})[status] || 'neutral';
export const flag = (status, tone = statusTone(status)) => `<span class="chip ${tone}">${h(status)}</span>`;
export const button = (action, label, glyph = 'plus', extra = '', classes = 'button') =>
    `<button type="button" class="${classes}" data-action="${action}" ${extra}>${icon(glyph)}${h(label)}</button>`;
export const empty = (glyph, title, text = '', action = '') =>
    `<div class="empty"><span class="tile-icon">${icon(glyph)}</span><h2>${h(title)}</h2>
    ${text ? `<p>${h(text)}</p>` : ''}${action}</div>`;

export const sectionIcons = {
    artwork: 'image', images: 'image', assets: 'folder', models: 'cube',
    animations: 'film', features: 'bolt', rules: 'book', sources: 'file'
};

export function nav(state, project, section) {
    const link = (href, label, glyph, current) => `<a class="nav-link${current ? ' active' : ''}"
        href="${href}" ${current ? 'aria-current="page"' : ''}>${icon(glyph)}<span>${h(label)}</span></a>`;
    const general = link('#overview', 'Panoramica', 'grid', !project && section === 'overview')
        + link('#projects', 'Videogiochi', 'game', !project && section === 'projects')
        + link('#workflow', 'Workflow', 'flow', !project && section === 'workflow');
    const perGame = project ? `<p class="nav-title game-nav-title">${h(project.name)}</p>
        ${link(gameUrl(project.id), 'Scheda progetto', 'grid', section === 'overview')}
        ${Object.entries(state.sections).map(([key, label]) =>
            link(gameUrl(project.id, key), label, sectionIcons[key], section === key)).join('')}` : '';
    return `<div class="nav-block"><p class="nav-title">Workspace</p>${general}</div>
        ${perGame ? `<div class="nav-block">${perGame}</div>` : ''}
        <div class="nav-block"><p class="nav-title">Impostazioni</p>
        ${link('#connections', 'Connessioni IA', 'plug', !project && section === 'connections')}
        ${link('#skills', 'Skill', 'book', !project && section === 'skills')}</div>`;
}

export function title(heading, subtitle = '', controls = '') {
    return `<div class="page-title"><div><h1>${h(heading)}</h1>${subtitle ? `<p>${h(subtitle)}</p>` : ''}</div>${controls}</div>`;
}

function stat(glyph, label, total, hint, tone) {
    return `<div class="stat panel"><span class="tile-icon ${tone}">${icon(glyph)}</span>
        <div><span class="stat-label">${h(label)}</span><strong>${total}</strong><small>${h(hint)}</small></div></div>`;
}

export function progress(done, total) {
    const percent = total ? Math.round(done / total * 100) : 0;
    return `<div class="progress"><div><span>Avanzamento</span><strong>${percent}%</strong></div>
        <progress max="100" value="${percent}" aria-label="Avanzamento"></progress></div>`;
}

export function card(game) {
    const cover = game.cover_entry_id ? `<img src="${fileUrl(game.id, game.cover_entry_id, true)}" alt="" width="600" height="300">`
        : `<span class="cover-placeholder">${icon('game')}</span>`;
    return `<a class="project-card panel" href="${gameUrl(game.id)}">
        <div class="project-cover">${cover}<div class="cover-status">${flag(game.archived ? 'Archiviato' : game.phase)}</div></div>
        <div class="project-info"><div class="project-meta"><span>${h(game.genre || 'Videogioco')}</span></div>
        <div class="project-name"><h3>${h(game.name)}</h3>${icon('next')}</div>
        ${progress(game.done, game.total)}</div></a>`;
}

export function overview(state) {
    const games = state.projects.filter(game => !game.archived);
    const tally = games.reduce((acc, game) => ({ total: acc.total + game.total, done: acc.done + game.done }), { total: 0, done: 0 });
    return `<section class="hero">
        <div class="hero-layout">
            <div class="hero-copy"><div class="overline"><span></span> IlChiriDev</div>
            <h1>Game <em>Dashboard</em></h1>
            <p>Dal briefing al playtest.<br>Organizza lo sviluppo dei tuoi videogiochi.</p>
            <a class="button primary" href="#projects">${icon('game')} Esplora i progetti</a></div>
            <div class="hero-visual" aria-hidden="true"></div>
        </div></section>
        <section class="stats" aria-label="Riepilogo">
        ${stat('game', 'Progetti attivi', games.length, 'Nel workspace', 'red')}
        ${stat('folder', 'Voci di progetto', tally.total, 'Materiali e attività', 'amber')}
        ${stat('check', 'Voci completate', tally.done, 'Sui progetti attivi', 'green')}
        </section>
        <section aria-labelledby="projects-heading"><div class="section-head"><div><h2 id="projects-heading">I tuoi videogiochi</h2></div>
        <a class="text-link" href="#projects">Tutti i progetti ${icon('next')}</a></div>
        ${games.length ? `<div class="project-grid">${games.slice(0, 3).map(card).join('')}</div>` :
            empty('game', 'Crea il primo videogioco', '', button('new-project', 'Nuovo progetto', 'plus', '', 'button primary'))}
        </section>`;
}

export function projects(state) {
    const live = state.projects.filter(game => !game.archived);
    const archived = state.projects.filter(game => game.archived);
    return title('Videogiochi', 'Apri la dashboard di un progetto.', button('new-project', 'Nuovo progetto', 'plus', '', 'button primary'))
        + (live.length ? `<div class="project-grid">${live.map(card).join('')}</div>`
            : empty('game', 'Nessun progetto attivo'))
        + (archived.length ? `<section class="spaced"><h2>Archivio</h2><div class="project-grid">${archived.map(card).join('')}</div></section>` : '');
}

export function workflow(state) {
    const games = state.projects.filter(game => !game.archived);
    return title('Workflow', 'Il percorso dei tuoi progetti, dal briefing alla pubblicazione.')
        + `<div class="phase-board">${state.phases.map(phase => {
            const column = games.filter(game => game.phase === phase);
            return `<section class="panel phase-column"><h2>${h(phase)}<span>${column.length}</span></h2>
                ${column.length ? column.map(game => `<a href="${gameUrl(game.id)}">${icon('game')}${h(game.name)}${icon('next')}</a>`).join('')
                    : '<p>Nessun progetto</p>'}</section>`;
        }).join('')}</div>`;
}

export function gameOverview(state, data) {
    const game = data.project;
    const done = data.entries.filter(x => x.status === 'Completato').length;
    return `<section class="panel game-header">
        <div class="game-header-copy"><div class="game-flags">${flag(game.phase)}
        ${game.archived ? flag('Archiviato') : ''}</div>
        <h1>${h(game.name)}</h1><p>${h(game.description || game.genre || 'Scheda progetto')}</p>
        ${game.folder_path ? `<p class="project-folder"><strong>Cartella di lavoro</strong><code>${h(game.folder_path)}</code></p>` : ''}
        <div class="button-row">${game.archived ? '' : button('edit-project', 'Modifica progetto', 'edit')}
        ${game.folder_path ? button('copy', 'Copia percorso', 'copy', `data-value="${h(game.folder_path)}" data-copy-message="Percorso copiato."`) : ''}
        ${game.folder_path && !game.archived ? button('import-project', 'Importa con l’IA', 'file') : ''}
        ${button('archive', game.archived ? 'Ripristina progetto' : 'Archivia progetto', 'folder')}</div></div></section>
        <div class="panel game-progress"><div><h2>Avanzamento</h2><p>${done} su ${data.entries.length} voci completate</p></div>
        ${progress(done, data.entries.length)}</div>
        <div class="section-head"><h2>Materiali e sviluppo</h2></div>
        <div class="collection-grid">${Object.entries(state.sections).map(([key, label]) => {
            const count = data.entries.filter(entry => entry.section === key).length;
            return `<a class="collection panel" href="${gameUrl(game.id, key)}"><span class="tile-icon red">${icon(sectionIcons[key])}</span>
                <span><strong>${h(label)}</strong><small>${count} ${count === 1 ? 'voce' : 'voci'}</small></span>${icon('next')}</a>`;
        }).join('')}</div>`;
}

function categoryNav(project, section, categories, entries, filter, suffix) {
    if (!categories.length && project.archived && !filter) return '';
    const counts = new Map();
    for (const entry of entries) {
        const key = entry.category_id ?? 'senza-categoria';
        counts.set(key, (counts.get(key) ?? 0) + 1);
    }
    const link = (key, label, count) => `<a class="category-link" href="${gameUrl(project.id, section, key) + h(suffix)}"
        aria-label="${h(label)}, ${count} ${count === 1 ? 'voce' : 'voci'}" ${key === filter ? 'aria-current="page"' : ''}>
        ${h(label)}<span aria-hidden="true">${count}</span></a>`;
    const actions = project.archived ? '' : `<div class="button-row">
        ${button('new-category', 'Aggiungi categoria')}
        ${typeof filter === 'number' ? button('edit-category', 'Rinomina', 'edit')
            + button('remove-category', 'Elimina categoria', 'trash', '', 'button danger') : ''}
        </div>`;
    const filters = categories.length || filter ? `<div class="category-links">
        ${link('', 'Tutte le voci', entries.length)}
        ${categories.map(category => link(category.id, category.name, counts.get(category.id) ?? 0)).join('')}
        ${counts.has('senza-categoria') || filter === 'senza-categoria'
            ? link('senza-categoria', 'Senza categoria', counts.get('senza-categoria') ?? 0) : ''}
        </div>` : '<p class="muted">Nessuna categoria.</p>';
    return `<nav class="category-nav panel" aria-label="Categorie">
        <div class="category-heading"><h2>Categorie</h2>${actions}</div>
        ${filters}</nav>`;
}

function entryFilterPanel(approvals, filters) {
    const choices = [['', 'Tutti'], ...Object.entries(approvals)];
    return `<div class="entry-filters panel">
        <label class="entry-filter">Cerca in questa sezione
            <input id="entry-search" type="search" value="${h(filters.search)}" maxlength="160"
                placeholder="Titolo, note o nome del file" autocomplete="off">
        </label>
        <fieldset class="approval-filters">
            <legend>Approvazione</legend>
            <div class="category-links">
            ${choices.map(([key, label]) => `<button type="button" class="category-link"
                data-approval-filter="${key}" aria-pressed="${key === filters.approval}">${h(label)}</button>`).join('')}
            </div>
        </fieldset>
        <p class="entry-result-count muted" role="status"></p>
    </div>`;
}

export function sectionView(state, data, section, filter, entryFilters) {
    const { project, entries } = data;
    const add = button('new-entry', 'Aggiungi voce', 'plus', '', 'button primary');
    const categories = data.categories.filter(category => category.section === section);
    const categoryNames = new Map(categories.map(category => [category.id, category.name]));
    const sectionEntries = entries.filter(entry => entry.section === section);
    if (section === 'artwork') {
        sectionEntries.sort((a, b) => Number(b.approval === 'approved') - Number(a.approval === 'approved'));
    }
    const list = filter ? sectionEntries.filter(entry => (entry.category_id ?? 'senza-categoria') === filter) : sectionEntries;
    return title(state.sections[section], project.name, project.archived ? '' : add)
        + categoryNav(project, section, categories, sectionEntries, filter, entryFilterSuffix(entryFilters))
        + entryFilterPanel(state.approvals, entryFilters)
        + '<p class="muted entry-search-empty" hidden>Nessuna voce corrisponde ai filtri.</p>'
        + (list.length ? `<div class="entries">${list.map(entry => {
            const preview = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'].includes(entry.mime);
            const approval = state.approvals[entry.approval];
            const tone = { approved: 'green', rejected: 'red', review: 'amber' }[entry.approval];
            const search = [entry.title, entry.notes, entry.filename, entry.url, categoryNames.get(entry.category_id)].join(' ');
            return `<article class="panel entry" data-approval="${entry.approval}" data-search="${h(search)}">
                ${preview ? `<img class="entry-image" loading="lazy" src="${fileUrl(project.id, entry.id, true)}" alt="${h(entry.title)}">` : ''}
                <div class="entry-body">
                ${!filter && categoryNames.has(entry.category_id) ? `<p class="entry-category">${h(categoryNames.get(entry.category_id))}</p>` : ''}
                <div class="entry-top"><h2>${h(entry.title)}</h2><div class="entry-badges">
                    <span title="Approvazione">${flag(approval, tone)}</span>
                    ${entry.status === approval ? '' : `<span title="Stato">${flag(entry.status)}</span>`}
                </div></div>
                ${entry.notes ? `<p class="user-text">${h(entry.notes)}</p>` : ''}
                <div class="button-row">
                ${entry.filename ? `<a class="button" href="${fileUrl(project.id, entry.id)}">${icon('file')}${h(entry.filename)}</a>` : ''}
                ${entry.url ? `<a class="button" href="${h(entry.url)}" target="_blank" rel="noopener noreferrer">Apri link</a>` : ''}
                ${project.archived ? '' : button('edit-entry', 'Modifica', 'edit', `data-id="${entry.id}"`)}
                </div></div></article>`;
        }).join('')}</div>` : empty(sectionIcons[section], filter ? 'Nessuna voce in questa categoria' : 'Nessuna voce in questa sezione',
            'Puoi registrare note, link e allegati in ogni voce.'));
}

export function connections(config) {
    const windows = /^[a-z]:/i.test(config.command);
    const quote = path => windows ? "'" + path.replaceAll("'", "''") + "'" : "'" + path.replaceAll("'", "'\\''") + "'";
    const invocation = [config.command, ...config.args].map(quote).join(' ');
    const commands = {
        codex: `codex mcp add ilchiridev -- ${invocation}`,
        claude: `claude mcp add --scope user --transport stdio ilchiridev -- ${invocation}`,
    };
    const genericConfig = JSON.stringify({ mcpServers: { ilchiridev: { command: config.command, args: config.args } } }, null, 2);
    const registration = name => `<div class="code-row"><code>${h(commands[name])}</code>
        ${button('copy', 'Copia', 'copy', `data-value="${h(commands[name])}"`)}</div>`;
    return title('Connessioni IA', 'Collega il registro dei videogiochi al client IA che usi tramite MCP.')
        + `<div class="connections">
        <section class="panel connection"><div class="connection-head"><span class="tile-icon red">${icon('plug')}</span><div><h2>Codex</h2>
        <p>Accesso al registro dal client Codex.</p></div></div>
        ${registration('codex')}
        <p>Esegui il comando nel terminale, poi usa <code>/mcp</code> in Codex per vedere gli strumenti del registro.</p></section>
        <section class="panel connection"><div class="connection-head"><span class="tile-icon amber">${icon('plug')}</span><div><h2>Claude Code</h2>
        <p>Accesso MCP dal client Claude Code.</p></div></div>
        <p>Accedi in Claude Code con il tuo account e registra il server dal terminale${windows ? ' PowerShell' : ''}.</p>
        ${registration('claude')}
        <p>Controlla la connessione con <code>claude mcp get ilchiridev</code> o con <code>/mcp</code> in Claude Code.</p>
        <p>In Claude Code, avvia la chat di progetto con <code>/mcp__ilchiridev__project_chat ID_PROGETTO</code>. Recupera l’ID con <code>list_projects</code>.</p></section>
        <section class="panel connection"><div class="connection-head"><span class="tile-icon blue">${icon('cube')}</span><div><h2>DeepSeek e Ollama</h2>
        <p>Accesso da un client compatibile con Ollama e MCP su stdio.</p></div></div>
        <p>Configura il modello Ollama nel client e aggiungi il server MCP nelle sue impostazioni.</p>
        <div class="code-row"><code>${h(genericConfig)}</code>
        ${button('copy', 'Copia JSON', 'copy', `data-value="${h(genericConfig)}"`)}</div></section>
        <section class="panel connection"><div class="connection-head"><span class="tile-icon red">${icon('flow')}</span><div><h2>Dati condivisi via MCP</h2>
        <p>Server locale stdio in sola lettura.</p></div></div>
        <p><code>list_projects</code> elenca i videogiochi attivi. <code>project_revision</code> controlla se il progetto è cambiato. <code>read_project</code> legge la scheda e fino a 40 voci per pagina.</p></section>
        </div>`;
}

export function skills() {
    const catalog = [
        ['game-asset-breakdown', 'Inventario e artwork degli asset', 'image',
            'Analizza un concept o uno screenshot, organizza gli asset e prepara le reference individuali quando servono.'],
        ['vehicle-reference-sheets', 'Schede multivista dei veicoli', 'grid',
            'Ricava viste coerenti da un concept approvato e verifica proporzioni e dettagli prima di modellare.'],
        ['blender-low-poly-vehicles', 'Veicoli low poly in Blender', 'cube',
            'Modella e ottimizza il veicolo, prepara ruote e materiali e controlla il GLB esportato.'],
        ['vehicle-texture-art-review', 'Revisione artistica delle texture', 'check',
            'Confronta render e riferimenti e individua le correzioni per materiali, livree e usura.'],
    ];
    const packagePath = '/downloads/game-dashboard-skills.zip';
    const pageUrl = new URL('/#skills', location.origin).href;
    const packageUrl = new URL(packagePath, location.origin).href;
    const prompt = [
        'Analizza e installa nel client IA di questa sessione le skill di Game Dashboard.',
        `1. Apri la sezione Skill (${pageUrl}) e scarica il pacchetto (${packageUrl}). Se puoi usare solo il terminale, scarica lo ZIP dal suo indirizzo.`,
        `2. Estrai lo ZIP in una cartella temporanea. Leggi i file SKILL.md e le risorse collegate di queste quattro skill: ${catalog.map(([id]) => id).join(', ')}.`,
        '3. Individua la cartella delle skill prevista dal client IA. Usa quella del progetto corrente se il client la supporta, altrimenti quella utente. Copia ogni cartella intera, incluse le risorse. Conserva eventuali versioni già installate con lo stesso nome e segnalamele.',
        '4. Verifica i percorsi installati, indica come richiamare le skill e segnala se occorre ricaricare il client. Se il client non supporta l’installazione o non può raggiungere la dashboard locale, dimmi quale passaggio manca.',
    ].join('\n\n');
    const download = `<a class="button primary" href="${packagePath}" download>${icon('folder')} Scarica le skill</a>`;
    return title('Skill', 'Scarica il pacchetto, estrailo e indica al tuo assistente IA il file SKILL.md della procedura che ti serve, o chiedigli di analizzare e installare direttamente le skill da questa sezione.', download)
        + `<details class="panel skill-install">
            <summary>Installazione con l’IA</summary>
            <div class="skill-install-content">
                <p class="muted">Incolla queste istruzioni in una sessione IA con accesso alla dashboard locale e ai file del PC.</p>
                <label>Istruzioni da incollare<textarea rows="8" readonly>${h(prompt)}</textarea></label>
                ${button('copy', 'Copia istruzioni per l’IA', 'copy', `data-value="${h(prompt)}" data-copy-message="Istruzioni copiate."`)}
            </div>
        </details>`
        + `<div class="connections">${catalog.map(([id, label, glyph, summary]) =>
            `<section class="panel connection"><div class="connection-head"><span class="tile-icon red">${icon(glyph)}</span>
            <div><h2>${h(label)}</h2><p>${h(summary)}</p></div></div><p><code>${h(id)}</code></p></section>`).join('')}</div>`;
}
