# Game Dashboard · IlChiriDev

Dashboard locale per seguire più videogiochi dal briefing alla pubblicazione. Ogni progetto ha una scheda, una fase di lavoro e raccolte per artwork e concept, altre immagini, asset, modelli 3D, animazioni, funzionalità, regole di gioco e fonti. Ogni voce può contenere note, uno stato, un link e un allegato fino a 20 MB.

## Avvio

Con il pacchetto portatile per Windows x64, estrai tutto lo ZIP in una cartella scrivibile e fai doppio clic su **Avvia-dashboard.cmd**. PHP è incluso in `runtime/php/`. Al primo avvio il registro locale parte vuoto. Per spegnere il server fai doppio clic su **Arresta-dashboard.cmd**.

Il PHP incluso usa il runtime Microsoft Visual C++ v14 per x64. Se Windows segnala che manca o che è da aggiornare, installalo dalla [pagina ufficiale Microsoft](https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist/), poi esegui di nuovo il launcher.

### macOS

Estrai il pacchetto macOS in una cartella scrivibile. Serve PHP 8.2 o successivo con PDO SQLite, mbstring e fileinfo. Su Apple Silicon puoi usare `brew install php` con [Homebrew](https://docs.brew.sh/Installation) se la tua versione di macOS è supportata. Su Intel, o se Homebrew non supporta la tua versione di macOS, puoi usare [MacPorts](https://www.macports.org/install.php) e il comando `sudo port install php84 php84-sqlite php84-mbstring`.

Apri **Terminale**, scrivi `bash` seguito da uno spazio, trascina **Avvia-dashboard.command** dalla cartella **Game Dashboard** nella finestra e premi Invio. La dashboard si apre nel browser predefinito. Usa Safari 15.4 o successivo oppure un altro browser aggiornato. Tieni il Terminale aperto e premi **Ctrl+C** per arrestarla. Se usi un PHP personalizzato, imposta `GAME_WORKFLOW_PHP` al percorso assoluto del binario.

### Avvio dai sorgenti

Serve PHP 8.2 o successivo con le estensioni PDO SQLite, mbstring e fileinfo. Il progetto usa PHP, JavaScript e CSS e parte senza gestori di pacchetti.

Su Windows fai doppio clic su **Avvia-dashboard.cmd**. Il launcher attende il server e apre il browser. Se la porta 8907 è occupata, prova le successive fino alla 8911. Per arrestare la dashboard esegui `Avvia-dashboard.cmd -Arresta`. Se PHP è in una cartella personalizzata, puoi indicare il percorso di `php.exe` in `GAME_WORKFLOW_PHP`.

Su tutti i sistemi puoi avviare il server anche da terminale, dalla cartella del progetto:

```sh
php -d upload_max_filesize=20M -d post_max_size=24M -S 127.0.0.1:8907 -t public public/index.php
```

Per avviare da terminale, apri [la dashboard locale](http://127.0.0.1:8907) dopo il comando. Il registro parte vuoto. Dopo aver creato il primo progetto, puoi aggiungere immagini in **Artwork e concept**. L’ultima immagine aggiunta appare sulla scheda nel registro.

Le fasi del workflow sono **Briefing**, **Prototipo**, **Concept / Produzione**, **Playtest** e **Pubblicato**. Alla migrazione del registro, le fasi precedenti **Concept** e **Produzione** confluiscono in **Concept / Produzione**.

Usa **Aggiungi categoria** nel pannello **Categorie** di ogni sezione. Scegli **Categoria** quando aggiungi o modifichi una voce. Apri una categoria per rinominarla o eliminarla. Dopo l’eliminazione, le sue voci restano nella sezione sotto **Senza categoria**.

Ogni sezione abbina ricerca per titolo, note, file, link o nome della categoria ai filtri **Approvato**, **Non approvato** e **Da rivedere**. Il campo **Approvazione** si modifica nella scheda della voce. Le nuove voci partono da **Da rivedere**.

Schede e file caricati sono in `var/workflow.sqlite`, ignorato da Git. Le voci collegate a originali locali conservano nel database il riferimento al file e lo aprono in sola lettura. A server fermo, copia il database per fare un backup. Il server è per uso personale su loopback. Distribuisci il codice sorgente e avvia una copia locale per ciascun utente.

In **Nuovo progetto** puoi creare una cartella vuota, collegare quella di un gioco già avviato oppure creare solo la scheda. Incolla il percorso assoluto. Per una cartella nuova indica anche il suo nome, dentro una cartella superiore già esistente. Puoi collegare una cartella anche da **Modifica progetto**.

Dopo aver collegato una cartella esistente, la dashboard mostra un prompt per una sessione IA con accesso ai file locali e alla dashboard. Il prompt resta disponibile in **Importa con l’IA**. Nelle singole voci il campo **File nella cartella di lavoro** collega un originale tramite un percorso relativo, ad esempio `Assets/Auto.glb`.

## MCP

**Connessioni IA** mostra i comandi di registrazione per Codex e Claude Code e una configurazione JSON per i client compatibili con MCP su stdio, inclusi quelli che usano Ollama. Le conversazioni si svolgono nel client scelto. Se usi `GAME_WORKFLOW_DATA_DIR`, passa lo stesso percorso assoluto alla dashboard e al client MCP.

Il server espone `list_projects`, `project_revision` e `read_project` in sola lettura. `read_project` accetta `section` e `offset` e restituisce fino a 40 voci per pagina. Per riusare la stessa pagina, passa la revisione precedente in `if_revision`. Se coincide, la risposta contiene solo l’ID, la revisione e `unchanged: true`. Allegati e cronologia della chat restano fuori dagli strumenti MCP.

In una sessione locale di Claude Code, usa `/mcp__ilchiridev__project_chat ID_PROGETTO` una volta per associare la chat al gioco. Il prompt MCP istruisce Claude a leggere la scheda e, per le domande successive sul progetto, a controllare la revisione prima di rileggere. Il comando richiede il server di questa dashboard collegato a Claude Code.

[Guida MCP Codex](https://learn.chatgpt.com/docs/cli/reference#codex-mcp) · [Guida MCP Claude Code](https://code.claude.com/docs/en/mcp)

## Skill

Apri **Impostazioni → Skill**, subito sotto **Connessioni IA**, per scaricare le quattro procedure. Estrai lo ZIP e indica al tuo assistente il file `SKILL.md` pertinente, lasciando insieme alla skill le sue risorse. I sorgenti sono in `skills/`.

In **Installazione con l’IA** trovi le istruzioni da copiare in un client con accesso alla dashboard locale e ai file del PC. Il prompt include il link diretto allo ZIP e i passaggi per analizzare, installare e verificare le skill nel client utilizzato.

Se aggiorni i sorgenti, ricrea il pacchetto dalla radice del progetto. In PowerShell usa `Compress-Archive -Path skills/* -DestinationPath public/downloads/game-dashboard-skills.zip -Force`.

## Grafica

L’icona di Game Dashboard riprende l’avatar illustrato del carosello Colori V02 di IlChiriDev. La barra laterale usa `public/media/ilchiridev-icon.png` e il browser usa `public/favicon.ico`. Il banner `public/media/hero.webp` è un’illustrazione ImageGen dello stesso avatar davanti a una scena neutra in un editor 3D.
