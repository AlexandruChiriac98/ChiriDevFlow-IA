#!/bin/bash
set -e

cd -P -- "$(dirname -- "$0")"

php_candidates=(php /opt/homebrew/bin/php /usr/local/bin/php /opt/local/bin/php84)
if [[ -n "${GAME_WORKFLOW_PHP:-}" ]]; then
    php_candidates=("$GAME_WORKFLOW_PHP")
fi

php_bin=''
for candidate in "${php_candidates[@]}"; do
    if command -v "$candidate" >/dev/null 2>&1 && "$candidate" -r '
        exit(PHP_SAPI === "cli" && PHP_VERSION_ID >= 80200 && extension_loaded("pdo_sqlite")
            && extension_loaded("mbstring") && extension_loaded("fileinfo") ? 0 : 1);
    '; then
        php_bin="$candidate"
        break
    fi
done

if [[ -z "$php_bin" ]]; then
    echo 'Serve PHP 8.2 o successivo con PDO SQLite, mbstring e fileinfo.' >&2
    echo 'Segui le istruzioni nel README o indica il percorso del binario in GAME_WORKFLOW_PHP.' >&2
    exit 1
fi

address=127.0.0.1:8907
url="http://$address"
if "$php_bin" -r 'exit(@stream_socket_client("tcp://" . $argv[1], $errno, $error, 0.3) ? 0 : 1);' "$address"; then
    echo 'La porta 8907 è già occupata. Se la dashboard è aperta, torna alla sua scheda nel browser.' >&2
    exit 1
fi

unset PHP_CLI_SERVER_WORKERS
"$php_bin" -d upload_max_filesize=20M -d post_max_size=24M -S "$address" -t public public/index.php &
server_pid=$!
trap 'kill "$server_pid" 2>/dev/null || true; wait "$server_pid" 2>/dev/null || true' EXIT
trap 'exit 0' HUP INT TERM

for ((attempt = 0; attempt < 30; attempt++)); do
    if ! kill -0 "$server_pid" 2>/dev/null; then
        echo 'Impossibile avviare la dashboard. Controlla se la porta 8907 è occupata.' >&2
        exit 1
    fi
    if health=$(curl -q --noproxy '*' -fs --max-time 1 "$url/health") && "$php_bin" -r '
        $health = json_decode(stream_get_contents(STDIN), true);
        $root = str_replace("\\", "/", getcwd());
        exit(($health["app"] ?? null) === "ilchiridev-game-workflow" && ($health["instance"] ?? null) === $root ? 0 : 1);
    ' <<< "$health"; then
        if ! curl -q --noproxy '*' -fs --max-time 8 -o /dev/null "$url/api?action=state"; then
            echo 'Impossibile aprire il registro. Controlla i permessi della cartella dati.' >&2
            exit 1
        fi
        printf 'Game Dashboard: %s\nPremi Ctrl+C per arrestarla.\n' "$url"
        open "$url" || printf 'Apri %s nel browser.\n' "$url"
        wait "$server_pid"
        exit
    fi
    sleep 0.2
done

echo 'Il server non ha risposto in tempo.' >&2
exit 1
