"""Blender CLI audit/export/render for a specified vehicle root; never save its source."""
import argparse
from collections import defaultdict
import json
import math
from pathlib import Path
import sys

sys.dont_write_bytecode = True

import bpy
import bmesh
from mathutils import Matrix, Vector

sys.path.insert(0, str(Path(__file__).resolve().parent))
from check_glb import inspect_glb


def family(root):
    return [root] + list(root.children_recursive)


def meshes(root):
    return sorted((o for o in family(root) if o.type == "MESH" and
                   not o.hide_render and o.get("vehicle_export", True)), key=lambda o: o.name)


def dynamic(obj):
    return bool(obj.get("vehicle_dynamic")) or obj.get("vehicle_role") == "wheel" or obj.name.lower().startswith(("ruota_", "wheel_"))


def bounds(objects, transform=None):
    transform = transform if transform is not None else Matrix.Identity(4)
    deps = bpy.context.evaluated_depsgraph_get()
    points = [transform @ o.matrix_world @ Vector(c) for o in objects for c in o.evaluated_get(deps).bound_box]
    if not points:
        raise ValueError("No mesh bounds")
    return {"min": [min(p[i] for p in points) for i in range(3)],
            "max": [max(p[i] for p in points) for i in range(3)]}


def audit(root, atlas=False, max_triangles=None):
    objects = meshes(root)
    errors, warnings, rows = [], [], []
    groups, group_cost, roles = defaultdict(list), {}, defaultdict(int)
    deps = bpy.context.evaluated_depsgraph_get()
    materials = set()
    if not objects:
        raise ValueError("Root has no exportable mesh descendants")
    if abs(root.matrix_world.determinant()) < 1e-10:
        raise ValueError("Singular root transform")
    for obj in objects:
        evaluated = obj.evaluated_get(deps)
        mesh = evaluated.to_mesh(preserve_all_data_layers=True, depsgraph=deps)
        bm = bmesh.new()
        try:
            mesh.calc_loop_triangles()
            bm.from_mesh(mesh)
            count = len(mesh.loop_triangles)
            empty = count == 0
            degenerate = sum(t.area < 1e-12 for t in mesh.loop_triangles)
            loose = sum(not v.link_edges for v in bm.verts)
            boundary = sum(e.is_boundary for e in bm.edges)
            junctions = sum(len(e.link_faces) > 2 for e in bm.edges)
            finite = all(math.isfinite(x) for v in mesh.vertices for x in v.co)
            uv = mesh.uv_layers.active
            uv_values = [float(v) for loop in uv.data for v in loop.uv] if uv else []
            uv_finite = all(math.isfinite(v) for v in uv_values)
            slots = [s.material for s in obj.material_slots if s.material]
            materials.update(m.name for m in slots)
            textured = any(m.use_nodes and any(n.type == "TEX_IMAGE" and n.image for n in m.node_tree.nodes) for m in slots)
            if empty or degenerate or loose or not finite:
                errors.append(f"{obj.name}: empty/degenerate/loose/non-finite geometry")
            if not uv_finite or (textured and not uv):
                errors.append(f"{obj.name}: invalid or missing texture UV")
            if atlas and uv_values and (min(uv_values) < -1e-6 or max(uv_values) > 1.000001):
                errors.append(f"{obj.name}: atlas UV outside 0-1")
            if boundary and not obj.get("vehicle_allow_open", False):
                warnings.append(f"{obj.name}: {boundary} undeclared boundary edges; inspect")
            if junctions:
                warnings.append(f"{obj.name}: non-manifold face junctions")
            if obj.matrix_world.determinant() <= 0:
                errors.append(f"{obj.name}: negative/singular transform")
            if any(abs(s - 1) > 1e-5 for s in obj.scale):
                warnings.append(f"{obj.name}: unapplied scale")
            if obj.modifiers:
                warnings.append(f"{obj.name}: evaluated modifiers included in counts and export")
            role = str(obj.get("vehicle_role", "wheel" if dynamic(obj) else "static"))
            roles[role] += count
            key = (obj.data.as_pointer(), tuple(m.as_pointer() for m in slots)) if not obj.modifiers else ("evaluated", obj.as_pointer())
            groups[key].append(obj.name)
            group_cost[key] = count
            rows.append({"name": obj.name, "role": role, "triangles": count,
                         "boundary_edges": boundary, "zero_area_triangles": degenerate,
                         "loose_vertices": loose, "has_uv": bool(uv),
                         "pivot_root": list(root.matrix_world.inverted() @ obj.matrix_world.translation)})
        finally:
            bm.free()
            evaluated.to_mesh_clear()
    total = sum(row["triangles"] for row in rows)
    if max_triangles is not None and total > max_triangles:
        errors.append(f"Triangle budget exceeded: {total} > {max_triangles}")
    return {"result": "FAIL" if errors else "PASS", "errors": errors, "warnings": warnings,
            "root": root.name, "triangles_instances": total,
            "triangles_resources_estimate": sum(group_cost.values()),
            "mesh_objects": len(objects), "materials": sorted(materials),
            "triangles_by_role": dict(roles), "parts_by_cost": sorted(rows, key=lambda x: -x["triangles"]),
            "shared_mesh_groups": [names for names in groups.values() if len(names) > 1],
            "bounds_root": bounds(objects, root.matrix_world.inverted()),
            "limits": "Technical checks only; sharing counts are conservative with modifiers. Inspect silhouettes, UV distortion and hidden surfaces visually."}


def write_report(path, report):
    with Path(path).open("x", encoding="utf-8") as output:
        json.dump(report, output, indent=2, ensure_ascii=False)


def export_vehicle(root, output, atlas=False, max_triangles=None):
    output = Path(output)
    if output.exists() or output.suffix.lower() != ".glb":
        raise ValueError("Output must be a new .glb path")
    if not output.parent.is_dir():
        raise ValueError("Output parent directory must exist")
    report = audit(root, atlas, max_triangles)
    if report["errors"]:
        raise ValueError("Audit failed: " + "; ".join(report["errors"]))
    if bpy.context.mode != "OBJECT":
        raise ValueError("Export requires Object mode")
    old_selection = list(bpy.context.selected_objects)
    old_active = bpy.context.view_layer.objects.active
    before_objects, before_meshes = set(bpy.data.objects), set(bpy.data.meshes)
    temp = bpy.data.collections.new("VEHICLE_EXPORT_TEMP")
    bpy.context.scene.collection.children.link(temp)
    temporary_root = bpy.data.objects.new(root.name + "_export", None)
    temp.objects.link(temporary_root)
    deps, cache, static, moving = bpy.context.evaluated_depsgraph_get(), {}, [], []
    root_inverse = root.matrix_world.inverted()
    try:
        for obj in meshes(root):
            mats = tuple(s.material.as_pointer() if s.material else 0 for s in obj.material_slots)
            key = (obj.data.as_pointer(), mats) if not obj.modifiers else ("evaluated", obj.as_pointer())
            if key not in cache:
                data = bpy.data.meshes.new_from_object(obj.evaluated_get(deps), preserve_all_data_layers=True, depsgraph=deps)
                cache[key] = data
            dup = bpy.data.objects.new(obj.name + "_export", cache[key])
            temp.objects.link(dup)
            dup.parent = temporary_root
            dup.matrix_basis = root_inverse @ obj.matrix_world
            dup["vehicle_source_name"] = obj.name
            if dynamic(obj):
                dup["vehicle_dynamic"] = True
                moving.append(dup)
            else:
                # Joining static copies can change their mesh; detach linked data first.
                dup.data = dup.data.copy()
                static.append(dup)
        bpy.ops.object.select_all(action="DESELECT")
        if static:
            for obj in static:
                obj.select_set(True)
            bpy.context.view_layer.objects.active = static[0]
            if len(static) > 1:
                bpy.ops.object.join()
            body = bpy.context.view_layer.objects.active
            body.name = root.name + "_body_export"
            body.data.transform(body.matrix_basis)
            body.matrix_basis = Matrix.Identity(4)
            body.data.update()
        bpy.ops.object.select_all(action="DESELECT")
        for obj in temp.objects:
            obj.select_set(True)
        bpy.context.view_layer.objects.active = temporary_root
        bpy.ops.export_scene.gltf(filepath=str(output), export_format="GLB", use_selection=True,
                                  export_yup=True, export_apply=False, export_extras=True, use_active_scene=True,
                                  export_cameras=False, export_lights=False)
        checked = inspect_glb(output, report["triangles_instances"], atlas)
        if checked["result"] != "PASS":
            raise ValueError("Export verification failed: " + "; ".join(checked["errors"]))
        checked["bounds_source_root"] = report["bounds_root"]
        checked["dynamic_pivots_root"] = {o.name: list(root_inverse @ o.matrix_world.translation)
                                          for o in meshes(root) if dynamic(o)}
        return checked
    finally:
        for obj in list(bpy.data.objects):
            if obj not in before_objects:
                bpy.data.objects.remove(obj, do_unlink=True)
        bpy.data.collections.remove(temp)
        for mesh in list(bpy.data.meshes):
            if mesh not in before_meshes and mesh.users == 0:
                bpy.data.meshes.remove(mesh)
        for obj in old_selection:
            obj.select_set(True)
        bpy.context.view_layer.objects.active = old_active


def verify_reimport(path, expected):
    """Use a temporary scene, keeping the loaded source and its selection intact."""
    old_scene = bpy.context.window.scene
    before_objects, before_meshes = set(bpy.data.objects), set(bpy.data.meshes)
    scene = bpy.data.scenes.new("VEHICLE_VERIFY_TEMP")
    bpy.context.window.scene = scene
    try:
        bpy.ops.import_scene.gltf(filepath=str(path))
        imported = [o for o in scene.objects if o.type == "MESH"]
        actual = bounds(imported)
        expected_bounds = expected["bounds_source_root"]
        error = max(abs(actual[k][i] - expected_bounds[k][i]) for k in ("min", "max") for i in range(3))
        pivots = expected.get("dynamic_pivots_root", {})
        found = {o.get("vehicle_source_name"): list(o.matrix_world.translation)
                 for o in imported if o.get("vehicle_dynamic")}
        pivot_error = max((max(abs(found[name][i] - p[i]) for i in range(3))
                           if name in found else float("inf") for name, p in pivots.items()), default=0)
        result = {"result": "PASS" if error < 1e-5 and pivot_error < 1e-5 else "FAIL",
                  "bounds_max_error": error, "pivot_max_error": pivot_error,
                  "mesh_objects": len(imported), "bounds": actual}
        if result["result"] != "PASS":
            raise ValueError("Reimport bounds/pivots mismatch: " + str(result))
        return result
    finally:
        bpy.context.window.scene = old_scene
        for obj in list(bpy.data.objects):
            if obj not in before_objects:
                bpy.data.objects.remove(obj, do_unlink=True)
        bpy.data.scenes.remove(scene)
        for mesh in list(bpy.data.meshes):
            if mesh not in before_meshes and mesh.users == 0:
                bpy.data.meshes.remove(mesh)


def render_views(root, output_dir, camera_name=None, studio_name=None, size=1000, samples=24):
    output_dir = Path(output_dir)
    if output_dir.exists():
        raise ValueError("Render directory must be new")
    if camera_name and (camera_name not in bpy.data.objects or bpy.data.objects[camera_name].type != "CAMERA"):
        raise ValueError("Named camera is missing or not a camera")
    if studio_name and studio_name not in bpy.data.collections:
        raise ValueError("Studio collection not found")
    output_dir.mkdir(parents=True)
    scene = bpy.context.scene
    keep = set(family(root))
    if studio_name:
        keep.update(bpy.data.collections[studio_name].all_objects)
    hidden = {o: o.hide_render for o in scene.objects}
    old_camera, old_format = scene.camera, scene.render.image_settings.file_format
    settings = {k: getattr(scene.render, k) for k in ("resolution_x", "resolution_y", "resolution_percentage", "filepath")}
    old_samples = scene.cycles.samples
    created = camera_name is None
    if created:
        camera_data = bpy.data.cameras.new("VEHICLE_RENDER_TEMP")
        camera = bpy.data.objects.new("VEHICLE_RENDER_TEMP", camera_data)
        scene.collection.objects.link(camera)
    else:
        camera = bpy.data.objects[camera_name]
    old_matrix, old_type, old_scale = camera.matrix_world.copy(), camera.data.type, camera.data.ortho_scale
    box = bounds(meshes(root))
    corners = [Vector((x, y, z)) for x in (box["min"][0], box["max"][0])
               for y in (box["min"][1], box["max"][1]) for z in (box["min"][2], box["max"][2])]
    center = (Vector(box["min"]) + Vector(box["max"])) / 2
    distance = (Vector(box["max"]) - Vector(box["min"])).length * 3
    directions = [("front-three-quarter", (-1, 1.25, .80)), ("rear-three-quarter", (1, -1.25, .70)),
                  ("left", (-1, 0, 0)), ("top", (0, 0, 1)), ("front", (0, 1, 0)), ("rear", (0, -1, 0))]
    try:
        for obj in hidden:
            obj.hide_render = hidden[obj] or obj not in keep
        scene.camera = camera
        scene.render.image_settings.file_format = "PNG"
        scene.render.resolution_x, scene.render.resolution_y = size, round(size * .75)
        scene.render.resolution_percentage = 100
        scene.cycles.samples = samples
        camera.data.type = "ORTHO"
        aspect = scene.render.resolution_x / scene.render.resolution_y
        orientation = root.matrix_world.to_quaternion()
        for name, direction in directions:
            eye_direction = orientation @ Vector(direction).normalized()
            camera.location = center + eye_direction * distance
            camera.rotation_euler = (-eye_direction).to_track_quat("-Z", "Y").to_euler()
            if name == "top":
                camera.rotation_euler.rotate_axis("Z", math.pi / 2)
            rotation = camera.rotation_euler.to_matrix().transposed()
            projected = [rotation @ (p - center) for p in corners]
            width = max(p.x for p in projected) - min(p.x for p in projected)
            height = max(p.y for p in projected) - min(p.y for p in projected)
            camera.data.ortho_scale = max(width, height * aspect) * 1.18
            scene.render.filepath = str(output_dir / (name + ".png"))
            bpy.ops.render.render(write_still=True)
        return [str(output_dir / (name + ".png")) for name, _ in directions]
    finally:
        for obj, value in hidden.items():
            obj.hide_render = value
        scene.camera = old_camera
        scene.render.image_settings.file_format = old_format
        for key, value in settings.items():
            setattr(scene.render, key, value)
        scene.cycles.samples = old_samples
        camera.matrix_world, camera.data.type, camera.data.ortho_scale = old_matrix, old_type, old_scale
        if created:
            bpy.data.objects.remove(camera, do_unlink=True)
            bpy.data.cameras.remove(camera_data)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("audit", "export", "render"):
        child = sub.add_parser(name)
        child.add_argument("--blend", required=True)
        child.add_argument("--root", required=True)
        child.add_argument("--report")
        child.add_argument("--atlas", action="store_true")
        child.add_argument("--max-triangles", type=int)
        if name == "export":
            child.add_argument("--output", required=True)
        elif name == "render":
            child.add_argument("--out-dir", required=True)
            child.add_argument("--camera")
            child.add_argument("--studio")
            child.add_argument("--size", type=int, default=1000)
            child.add_argument("--samples", type=int, default=24)
    argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    args = parser.parse_args(argv)
    if args.report and Path(args.report).exists():
        raise ValueError("Report exists")
    bpy.ops.wm.open_mainfile(filepath=str(Path(args.blend).resolve()))
    root = bpy.data.objects.get(args.root)
    if root is None:
        raise ValueError("Vehicle root not found")
    if args.command == "audit":
        report = audit(root, args.atlas, args.max_triangles)
    elif args.command == "export":
        report = export_vehicle(root, args.output, args.atlas, args.max_triangles)
        report["reimport"] = verify_reimport(args.output, report)
    else:
        report = {"result": "PASS", "images": render_views(root, args.out_dir, args.camera, args.studio, args.size, args.samples),
                  "limits": "These renders still require visual comparison against the approved reference."}
    if args.report:
        write_report(args.report, report)
    print(json.dumps(report, indent=2, ensure_ascii=False), flush=True)
    if report["result"] != "PASS":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
