"""Inspect a self-contained triangle GLB using only Python's standard library."""
import argparse
import json
import math
import struct
from pathlib import Path


def inspect_glb(path, expected_instances=None, atlas=False):
    blob = Path(path).read_bytes()
    errors = []
    if len(blob) < 20:
        raise ValueError("Truncated GLB")
    magic, version, size = struct.unpack_from("<4sII", blob)
    if magic != b"glTF" or version != 2 or size != len(blob):
        raise ValueError("Invalid GLB header")
    offset, document, binary = 12, None, None
    while offset < len(blob):
        if offset + 8 > len(blob):
            raise ValueError("Truncated chunk header")
        length, kind = struct.unpack_from("<II", blob, offset)
        offset += 8
        if length % 4 or offset + length > len(blob):
            raise ValueError("Invalid chunk length")
        chunk = blob[offset:offset + length]
        offset += length
        if kind == 0x4E4F534A:
            document = json.loads(chunk)
        elif kind == 0x004E4942:
            binary = chunk
    if document is None:
        raise ValueError("Missing JSON chunk")
    binary = binary or b""
    types = {5120: "b", 5121: "B", 5122: "h", 5123: "H", 5125: "I", 5126: "f"}
    widths = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4, "MAT4": 16}

    def accessor(index):
        a = document["accessors"][index]
        if "sparse" in a:
            raise ValueError("Sparse accessors require a dedicated validator")
        view = document["bufferViews"][a["bufferView"]]
        if view.get("buffer", 0) != 0:
            raise ValueError("Only embedded buffer 0 is supported")
        fmt = "<" + types[a["componentType"]] * widths[a["type"]]
        item_size = struct.calcsize(fmt)
        stride = view.get("byteStride", item_size)
        start = view.get("byteOffset", 0) + a.get("byteOffset", 0)
        end = start + max(0, a["count"] - 1) * stride + (item_size if a["count"] else 0)
        if stride < item_size or end > len(binary) or end > view.get("byteOffset", 0) + view["byteLength"]:
            raise ValueError("Accessor outside its buffer view")
        return [struct.unpack_from(fmt, binary, start + i * stride) for i in range(a["count"])]

    counts, primitive_count, max_normal_error = [], 0, 0.0
    uv_min, uv_max = float("inf"), float("-inf")
    for mi, mesh in enumerate(document.get("meshes", [])):
        count = 0
        for pi, primitive in enumerate(mesh.get("primitives", [])):
            primitive_count += 1
            label = f"mesh {mi} primitive {pi}"
            if primitive.get("mode", 4) != 4:
                errors.append(label + ": not triangles")
                continue
            attributes = primitive.get("attributes", {})
            if "POSITION" not in attributes:
                errors.append(label + ": no positions")
                continue
            positions = accessor(attributes["POSITION"])
            indices = ([x[0] for x in accessor(primitive["indices"])]) if "indices" in primitive else list(range(len(positions)))
            if len(indices) % 3 or any(i < 0 or i >= len(positions) for i in indices):
                errors.append(label + ": invalid triangle indices")
            count += len(indices) // 3
            if not all(math.isfinite(v) for p in positions for v in p):
                errors.append(label + ": non-finite positions")
            if "NORMAL" not in attributes:
                errors.append(label + ": no normals")
            else:
                normals = accessor(attributes["NORMAL"])
                if len(normals) != len(positions) or not all(math.isfinite(v) for n in normals for v in n):
                    errors.append(label + ": invalid normals")
                else:
                    max_normal_error = max(max_normal_error, max((abs(math.sqrt(sum(v * v for v in n)) - 1) for n in normals), default=0))
            if "TEXCOORD_0" in attributes:
                uv = accessor(attributes["TEXCOORD_0"])
                if len(uv) != len(positions) or not all(math.isfinite(v) for p in uv for v in p):
                    errors.append(label + ": invalid UV")
                elif uv:
                    uv_min = min(uv_min, min(v for p in uv for v in p))
                    uv_max = max(uv_max, max(v for p in uv for v in p))
            elif document.get("images"):
                errors.append(label + ": textures present but no UV")
        counts.append(count)
    if max_normal_error > 1e-4:
        errors.append("Non-unit normals")
    if atlas and uv_min != float("inf") and (uv_min < -1e-6 or uv_max > 1.000001):
        errors.append("Atlas UV outside 0-1")
    # Count node occurrences in the active scene, including repeated mesh resources.
    nodes = document.get("nodes", [])
    if len(document.get("scenes", [])) != 1:
        errors.append("Vehicle export must contain exactly one scene")
    roots = document.get("scenes", [{}])[document.get("scene", 0)].get("nodes", [])
    instances, node_count = 0, 0

    def visit(index, ancestors):
        nonlocal instances, node_count
        if index in ancestors:
            raise ValueError("Cyclic scene graph")
        node = nodes[index]
        if "mesh" in node:
            instances += counts[node["mesh"]]
            node_count += 1
        for child in node.get("children", []):
            visit(child, ancestors | {index})

    for index in roots:
        visit(index, set())
    if not counts or not instances:
        errors.append("No triangle model in active scene")
    if expected_instances is not None and instances != expected_instances:
        errors.append(f"Triangle mismatch: {instances} != {expected_instances}")
    if document.get("cameras") or "KHR_lights_punctual" in document.get("extensions", {}):
        errors.append("Cameras or lights included in model export")
    embedded = all("bufferView" in image for image in document.get("images", []))
    if not embedded:
        errors.append("External image dependency")
    return {"result": "FAIL" if errors else "PASS", "errors": errors,
            "triangles_unique": sum(counts), "triangles_instances": instances,
            "mesh_resources": len(counts), "mesh_nodes": node_count,
            "primitives_unique": primitive_count, "materials": len(document.get("materials", [])),
            "images": len(document.get("images", [])), "images_embedded": embedded,
            "normal_max_length_error": max_normal_error,
            "uv_range": None if uv_min == float("inf") else [uv_min, uv_max], "bytes": len(blob)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("glb")
    parser.add_argument("--expected-instances", type=int)
    parser.add_argument("--atlas", action="store_true")
    args = parser.parse_args()
    report = inspect_glb(args.glb, args.expected_instances, args.atlas)
    print(json.dumps(report, indent=2))
    return 0 if report["result"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
