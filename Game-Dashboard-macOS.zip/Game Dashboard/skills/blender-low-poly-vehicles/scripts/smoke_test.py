"""Run isolated behavioral checks in Blender; outputs require a new directory."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import sys

sys.dont_write_bytecode = True

import bpy
from mathutils import Vector

sys.path.insert(0, str(Path(__file__).resolve().parent))
from mesh_helpers import plate, tube, wheel, instance_wheels, seat_fastener
from vehicle_tool import audit, export_vehicle, verify_reimport, render_views
from check_glb import inspect_glb


def rejected(call):
    try:
        call()
    except (ValueError, FileExistsError):
        return True
    return False


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out-dir", required=True)
    args = parser.parse_args(sys.argv[sys.argv.index("--") + 1:])
    out = Path(args.out_dir)
    if out.exists():
        raise ValueError("Test directory must be new")
    out.mkdir(parents=True)
    scene = bpy.data.scenes.new("Isolated_vehicle_skill_test")
    bpy.context.window.scene = scene
    collection = bpy.data.collections.new("Fixture_model")
    scene.collection.children.link(collection)
    root = bpy.data.objects.new("Fixture_root", None)
    collection.objects.link(root)
    material = bpy.data.materials.new("Fixture_color")
    material.diffuse_color = (.6, .035, .015, 1)
    material.use_nodes = True
    bsdf = next(n for n in material.node_tree.nodes if n.type == "BSDF_PRINCIPLED")
    bsdf.inputs["Base Color"].default_value = (.6, .035, .015, 1)
    body = plate("Body", [(-.55, -1.2, .30), (.55, -1.2, .30),
                          (.55, 1.2, .30), (-.55, 1.2, .30)], .40, (0, 0, 1), collection, material)
    body.parent = root
    cabin = plate("Cabin", [(-.4, -.55, .70), (.4, -.55, .70), (.4, .25, .70), (-.4, .25, .70)],
                  .33, (0, 0, 1), collection, material)
    cabin.parent = root
    bar = tube("Straight_bar", [(-.4, .9, .76), (0, .9, .76), (.4, .9, .76)],
               .025, collection, material)
    bar.parent = root
    prototype = wheel("Prototype", .32, .20, collection, material)
    wheels = instance_wheels(prototype, [("Wheel_LF", (-.60, .75, .32), -1),
                                        ("Wheel_LR", (-.60, -.75, .32), -1),
                                        ("Wheel_RF", (.60, .75, .32), 1),
                                        ("Wheel_RR", (.60, -.75, .32), 1)], root)
    bpy.data.objects.remove(prototype, do_unlink=True)
    fastener = plate("Necessary_anchor", [(.10, .4, .8), (.14, .4, .8),
                                          (.14, .44, .8), (.10, .44, .8)], .015,
                     (0, 0, 1), collection, material)
    fastener.parent = root
    fastener.rotation_euler.z = math.pi / 5
    bpy.context.view_layer.update()
    anchor = fastener.matrix_world @ Vector((.12, .42, .8))
    contact = seat_fastener(fastener, anchor, (0, 0, 1), [body], .2)
    landed = fastener.matrix_world @ Vector((.12, .42, .8))
    checks = {"shared_wheels": len({o.data.as_pointer() for o in wheels}) == 1,
              "wheel_side_orientation": all(o.matrix_world.determinant() > 0 for o in wheels),
              "collinear_tube_points_removed": len(bar.data.vertices) == 12,
              "rotated_fastener_contact": abs(landed.z - .70) < 1e-5 and contact["host"] == body.name,
              "invalid_tube_rejected": rejected(lambda: tube("Bad", [(0, 0, 0)] * 2, .1, collection)),
              "missing_support_rejected": rejected(lambda: seat_fastener(fastener, (0, 0, 5), (0, 0, 1), [body], .01))}
    report = audit(root, atlas=True)
    checks["valid_fixture_audit"] = report["result"] == "PASS"
    checks["budget_violation_detected"] = audit(root, max_triangles=1)["result"] == "FAIL"
    uv = body.data.uv_layers.active.data[0]
    old_uv = uv.uv.copy()
    uv.uv.x = 2
    checks["atlas_uv_violation_detected"] = audit(root, atlas=True)["result"] == "FAIL"
    uv.uv = old_uv
    broken_data = bpy.data.meshes.new("Broken")
    broken_data.from_pydata([(0, 0, 0), (1, 0, 0), (2, 0, 0), (4, 0, 0)], [], [(0, 1, 2)])
    broken = bpy.data.objects.new("Broken", broken_data)
    collection.objects.link(broken)
    broken.parent = root
    checks["degenerate_and_loose_detected"] = audit(root)["result"] == "FAIL"
    bpy.data.objects.remove(broken, do_unlink=True)
    bpy.data.meshes.remove(broken_data)
    source = out / "fixture.blend"
    preview = bpy.context.preferences.filepaths.bl_rna.properties.get("file_preview_type")
    if preview and "NONE" in {item.identifier for item in preview.enum_items}:
        bpy.context.preferences.filepaths.file_preview_type = "NONE"
    bpy.ops.wm.save_as_mainfile(filepath=str(source))
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    before_objects = len(bpy.data.objects)
    exported = export_vehicle(root, out / "fixture.glb", atlas=True)
    checks["export_restores_object_inventory"] = before_objects == len(bpy.data.objects)
    checks["two_mesh_resources_five_nodes"] = exported["mesh_resources"] == 2 and exported["mesh_nodes"] == 5
    checks["export_triangle_match"] = exported["triangles_instances"] == report["triangles_instances"]
    checks["reimport_bounds_and_pivots"] = verify_reimport(out / "fixture.glb", exported)["result"] == "PASS"
    checks["output_overwrite_rejected"] = rejected(lambda: export_vehicle(root, out / "fixture.glb"))
    checks["wrong_expected_count_detected"] = inspect_glb(out / "fixture.glb", expected_instances=1)["result"] == "FAIL"
    (out / "truncated.glb").write_bytes(b"glTF")
    checks["truncated_glb_rejected"] = rejected(lambda: inspect_glb(out / "truncated.glb"))
    try:
        scene.render.engine = "BLENDER_WORKBENCH"
    except TypeError:
        scene.render.engine = "CYCLES"
        scene.world = bpy.data.worlds.new("Fixture_world")
        scene.world.use_nodes = True
    files = render_views(root, out / "views", size=256, samples=1)
    checks["six_nonempty_renders"] = len(files) == 6 and all(Path(f).stat().st_size > 100 for f in files)
    checks["source_file_unchanged"] = digest == hashlib.sha256(source.read_bytes()).hexdigest()
    wheels[0].data.calc_loop_triangles()
    result = {"result": "PASS" if all(checks.values()) else "FAIL", "checks": checks,
              "fixture_triangles": report["triangles_instances"], "export": exported,
              "wheel_triangles_each": len(wheels[0].data.loop_triangles)}
    (out / "test-results.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2), flush=True)
    assert result["result"] == "PASS", "Behavioral tests failed"


if __name__ == "__main__":
    main()
