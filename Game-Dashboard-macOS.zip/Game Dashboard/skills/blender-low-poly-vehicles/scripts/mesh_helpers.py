"""Low-cost bpy geometry helpers. Importing this module never changes a scene."""
import math

import bpy
import bmesh
from mathutils import Vector
from mathutils.bvhtree import BVHTree


def mesh_object(name, vertices, faces, collection, material=None, role="body", open_surface=False):
    if not vertices or not faces:
        raise ValueError("A mesh needs vertices and faces")
    if any(not all(math.isfinite(float(x)) for x in p) for p in vertices):
        raise ValueError("Non-finite vertex")
    mesh = bpy.data.meshes.new(name + "_mesh")
    mesh.from_pydata(vertices, [], faces)
    mesh.update()
    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        if any(f.calc_area() < 1e-12 for f in bm.faces):
            raise ValueError("Degenerate face")
        bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
        bm.to_mesh(mesh)
    except Exception:
        bpy.data.meshes.remove(mesh)
        raise
    finally:
        bm.free()
    obj = bpy.data.objects.new(name, mesh)
    collection.objects.link(obj)
    if material is not None:
        mesh.materials.append(material)
    obj["vehicle_role"] = role
    obj["vehicle_allow_open"] = bool(open_surface)
    uv = mesh.uv_layers.new(name="UVMap")
    lo = [min(v.co[i] for v in mesh.vertices) for i in range(3)]
    hi = [max(v.co[i] for v in mesh.vertices) for i in range(3)]
    for face in mesh.polygons:
        axes = [i for i in range(3) if i != max(range(3), key=lambda a: abs(face.normal[a]))]
        extent = max(hi[a] - lo[a] for a in axes) or 1.0
        for li in face.loop_indices:
            co = mesh.vertices[mesh.loops[li].vertex_index].co
            uv.data[li].uv = tuple(.05 + .9 * (co[a] - lo[a]) / extent for a in axes)
    return obj


def plate(name, points, thickness, normal, collection, material=None):
    points = [Vector(p) for p in points]
    if len(points) < 3 or thickness < 0 or Vector(normal).length == 0:
        raise ValueError("Invalid plate")
    if len({tuple(p) for p in points}) != len(points):
        raise ValueError("Repeated plate corner")
    count = len(points)
    if thickness == 0:
        return mesh_object(name, points, [tuple(range(count))], collection, material,
                           role="panel", open_surface=True)
    offset = Vector(normal).normalized() * thickness
    vertices = points + [p + offset for p in points]
    faces = [tuple(reversed(range(count))), tuple(range(count, count * 2))]
    faces += [(i, (i + 1) % count, (i + 1) % count + count, i + count) for i in range(count)]
    return mesh_object(name, vertices, faces, collection, material, role="panel")


def tube(name, points, radius, collection, material=None, sides=6, caps=True):
    if radius <= 0 or sides < 3:
        raise ValueError("Invalid tube radius or side count")
    clean = []
    for p in map(Vector, points):
        if clean and (p - clean[-1]).length < 1e-8:
            continue
        while len(clean) >= 2:
            a, b = clean[-1] - clean[-2], p - clean[-1]
            if a.normalized().dot(b.normalized()) > .999999:
                clean.pop()
            else:
                break
        clean.append(p)
    if len(clean) < 2:
        raise ValueError("Tube needs two distinct points")
    verts, faces, previous = [], [], None
    for k, p in enumerate(clean):
        tangent = clean[min(k + 1, len(clean) - 1)] - clean[max(0, k - 1)]
        if tangent.length < 1e-8:
            raise ValueError("Tube reverses onto itself")
        tangent.normalize()
        ref = Vector((0, 0, 1)) if abs(tangent.z) < .95 else Vector((1, 0, 0))
        a = tangent.cross(ref) if previous is None else previous - tangent * previous.dot(tangent)
        if a.length < 1e-8:
            a = tangent.cross(ref)
        a.normalize()
        b = tangent.cross(a).normalized()
        previous = a
        verts += [p + radius * (a * math.cos(j * math.tau / sides) + b * math.sin(j * math.tau / sides))
                  for j in range(sides)]
    for k in range(len(clean) - 1):
        for j in range(sides):
            faces.append((k * sides + j, k * sides + (j + 1) % sides,
                          (k + 1) * sides + (j + 1) % sides, (k + 1) * sides + j))
    if caps:
        faces += [tuple(reversed(range(sides))),
                  tuple((len(clean) - 1) * sides + j for j in range(sides))]
    return mesh_object(name, verts, faces, collection, material, "tube", not caps)


def wheel(name, radius, width, collection, material=None, sides=12, uv_regions=None):
    """One outward +X rim; no geometric bolts. Instances orient the outward face."""
    if radius <= 0 or width <= 0 or sides < 6:
        raise ValueError("Invalid wheel dimensions")
    half = width / 2
    profiles = [
        ("tire", [(-half, .60 * radius), (-half, .81 * radius),
                  (-half * .70, radius), (half * .70, radius),
                  (half, .81 * radius), (half, .60 * radius)]),
        ("rim", [(half * .90, .62 * radius), (half * 1.02, .60 * radius),
                 (half * .80, .52 * radius), (half * .76, .46 * radius)]),
    ]
    verts, faces, surfaces = [], [], []
    for kind, profile in profiles:
        base = len(verts)
        for x, r in profile:
            verts += [(x, r * math.cos(j * math.tau / sides), r * math.sin(j * math.tau / sides))
                      for j in range(sides)]
        # Annular cross-section. A full circular end cap would cover the rim recess.
        for k in range(len(profile)):
            nxt = (k + 1) % len(profile)
            for j in range(sides):
                faces.append((base + k * sides + j, base + k * sides + (j + 1) % sides,
                              base + nxt * sides + (j + 1) % sides, base + nxt * sides + j))
                surfaces.append("tread" if kind == "tire" and k == 2 else kind)
    start = len(verts)
    verts += [(half * .765, radius * .458 * math.cos(j * math.tau / sides),
               radius * .458 * math.sin(j * math.tau / sides)) for j in range(sides)]
    faces.append(tuple(range(start, start + sides)))
    surfaces.append("hub")
    obj = mesh_object(name, verts, faces, collection, material, "wheel", True)
    obj["vehicle_dynamic"] = True
    obj["vehicle_spin_axis"] = "X"
    obj["vehicle_open_reason"] = "Recessed outward hub is an intentional plane"
    uv = obj.data.uv_layers.active.data
    for face, kind in zip(obj.data.polygons, surfaces):
        points = [obj.data.vertices[obj.data.loops[li].vertex_index].co for li in face.loop_indices]
        angles = [(math.atan2(p.z, p.y) % math.tau) / math.tau for p in points]
        if max(angles) - min(angles) > .5:
            angles = [a + 1 if a < .5 else a for a in angles]
        rect = (uv_regions or {}).get(kind, (0, 0, 1, 1))
        if len(rect) != 4 or not (0 <= rect[0] < rect[2] <= 1 and 0 <= rect[1] < rect[3] <= 1):
            raise ValueError("UV region must be a rectangle within 0-1")
        for li, p, angle in zip(face.loop_indices, points, angles):
            u, v = ((p.x + half) / width, angle) if kind == "tread" else (.5 + p.y / (2.1 * radius), .5 + p.z / (2.1 * radius))
            uv[li].uv = (rect[0] + (.02 + .96 * u) * (rect[2] - rect[0]),
                         rect[1] + (.02 + .96 * v) * (rect[3] - rect[1]))
    return obj


def instance_wheels(prototype, placements, root):
    """placements: iterable of (name, root-local center, outward_side +/-1)."""
    result = []
    for name, center, side in placements:
        if side not in (-1, 1):
            raise ValueError("Wheel outward_side must be +1 or -1")
        obj = prototype.copy()
        obj.data = prototype.data
        obj.name = name
        root.users_collection[0].objects.link(obj)
        obj.parent = root
        obj.location = center
        obj.rotation_euler = (0, 0, math.pi if side < 0 else 0)
        obj.scale = (1, 1, 1)
        result.append(obj)
    return result


def seat_fastener(obj, anchor_world, normal_world, hosts, max_distance, clearance=0.0):
    """Explicit backing meshes only. Caller decides whether geometry is warranted."""
    anchor, normal = Vector(anchor_world), Vector(normal_world)
    if normal.length == 0 or max_distance <= 0 or clearance < 0:
        raise ValueError("Invalid contact parameters")
    normal.normalize()
    margin = max_distance * .1
    origin = anchor + normal * margin
    deps = bpy.context.evaluated_depsgraph_get()
    hits = []
    for host in hosts:
        if host == obj or host.type != "MESH":
            continue
        inv = host.matrix_world.inverted()
        ray = (inv.to_3x3() @ -normal).normalized()
        bvh = BVHTree.FromObject(host, deps)
        point, _, _, _ = bvh.ray_cast(inv @ origin, ray)
        if point is not None:
            world = host.matrix_world @ point
            distance = (world - origin).length
            if distance <= max_distance + margin:
                hits.append((distance, host.name, world))
    if not hits:
        raise ValueError("No explicit backing surface within max_distance")
    _, host_name, point = min(hits, key=lambda hit: hit[0])
    matrix = obj.matrix_world.copy()
    matrix.translation += point + normal * clearance - anchor
    obj.matrix_world = matrix
    bpy.context.view_layer.update()
    return {"host": host_name, "contact": list(point), "clearance": clearance}
