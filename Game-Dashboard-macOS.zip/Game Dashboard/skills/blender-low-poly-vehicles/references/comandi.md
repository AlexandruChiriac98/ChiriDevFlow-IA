# Helper Blender

Esegui gli script bpy con il Blender del progetto. Usa i percorsi reali e il nome del root del veicolo al posto dei valori di esempio. Passa `--python-exit-code 1` per distinguere gli errori Python dalla chiusura normale di Blender.

```sh
blender --background --python-exit-code 1 --python scripts/vehicle_tool.py -- audit --blend veicolo.blend --root Veicolo
blender --background --python-exit-code 1 --python scripts/vehicle_tool.py -- export --blend veicolo.blend --root Veicolo --output veicolo.glb
python scripts/check_glb.py veicolo.glb
blender --background --python-exit-code 1 --python scripts/vehicle_tool.py -- render --blend veicolo.blend --root Veicolo --out-dir viste
```

- **Audit** ispeziona i discendenti mesh del root. `--report` scrive un file nuovo, `--atlas` controlla UV in 0–1 e `--max-triangles` accetta il limite stabilito per il lavoro.
- **Export** usa copie temporanee, unisce le parti statiche e conserva le ruote con proprietà `vehicle_role=wheel` o nome `Ruota_…` / `Wheel_…`. Per altre parti mobili usa `vehicle_dynamic=true`. Il percorso di destinazione deve essere nuovo.
- **Render** genera sei viste ortografiche da una camera temporanea o dalla camera indicata con `--camera`. `--studio` consente di mantenere una collezione luci esistente. Prepara prima uno studio neutro se il sorgente è privo di luci. La cartella di output deve essere nuova.
- **check_glb.py** usa Python standard. Controlla struttura e triangoli per risorsa e per istanza. Passa `--expected-instances` soltanto se disponi del conteggio del veicolo corrente.
- **mesh_helpers.py** espone funzioni bpy per piastre, tubi, ruote e fissaggi. Importalo da un builder aggiungendo la cartella `scripts` a `sys.path`. Passa esplicitamente collection e materiali. Per ruote compatibili usa `instance_wheels`, con centri e lati esterni indipendenti. Prima dell’export controlla le UV basilari degli helper contro la mappatura effettiva.

Per provare la configurazione, esegui `blender --background --python-exit-code 1 --python scripts/smoke_test.py -- --out-dir prova-blender` con una cartella di destinazione nuova. La prova crea dati sintetici e verifica audit, render, GLB e rifiuto delle sovrascritture.
