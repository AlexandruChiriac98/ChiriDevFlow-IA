---
name: blender-low-poly-vehicles
description: Modella, corregge e ottimizza auto, furgoni e buggy low poly in Blender da concept o schede del gioco. Usa per geometria, ruote articolabili, materiali, verifica visuale ed export GLB.
---

# Veicoli low poly in Blender

## Prima di modellare

- Individua le viste e la revisione di partenza, la scala di gioco, i limiti di geometria e le convenzioni di assi e pivot. Il concept del veicolo decide forme e dettagli. Gli altri modelli aiutano a confrontare qualità o organizzazione tecnica.
- Controlla silhouette, passo, sbalzi, rapporto ruote/cabina, montanti e accessori identitari in più viste prima di costruire. Dichiara quando un’immagine non consente di ricavare una misura.
- Lavora in una nuova revisione. Se l’incarico riguarda solo le texture, conserva esattamente geometria, UV, dimensioni, ruote e pivot della base approvata.
- Usa Blender via collegamento locale oppure CLI con bpy. Gli [helper inclusi](references/comandi.md) coprono costruzione, audit, export e viste. Usa un file o una sessione isolata per prove e reimportazione.

## Geometria per il gioco

1. Costruisci prima scocca e abitacolo. Controlla larghezza, altezza, lunghezza e silhouette in ortogonale a scala coerente. Poi aggiungi attacchi e raccordi. Le prese aperte richiedono un incasso reale con labbro, parete e fondo. Verifica profondità e attacchi da profilo e tre quarti.
2. Usa la geometria necessaria per distinguere silhouette e riflessi alla distanza prevista. Trasferisci in texture o bake dettagli piccoli come rivetti, graffi e battistrada, salvo che incidano sulla sagoma. Semplifica ruote e tubi in modo mirato. Rimuovi tappi e facce nascoste solo dopo aver controllato le viste utili.
3. Mantieni un root coerente con il progetto e i pivot ruota nei centri reali. Condividi la mesh delle ruote compatibili preservando gli orientamenti e i pivot indipendenti. Conta separatamente triangoli delle risorse uniche e triangoli delle istanze valutate. Evita scale negative sulle ruote invertite.
4. Per un abitacolo abitabile verifica seduta, appoggi e raggiungibilità dei comandi con la base del progetto o un manichino alla scala prevista. Controlla interferenze con tetto, pavimento e vetri. Escludi il manichino dall’export.

## Materiali e varianti

- Distingui vernice, metallo, gomma e vetro. Controlla UV, densità, margini e stiramenti. Se è prevista finitura vissuta, distribuiscila secondo superficie, giunti e punti di sfregamento visibili. Verifica materiali semitrasparenti anche dopo l’export.
- Usa una sola mesh canonica per livree che condividono la forma. Tieni colore, maschere, usura e preset separati quando richiesto dal progetto. Verifica le varianti sulla stessa geometria reimportata.

## Verifica e consegna

- Esegui un audit sul root. Controlla conteggi, pivot, trasformazioni, bordi aperti, facce nulle, vertici isolati e UV. Usa il vincolo UV 0–1 soltanto per atlanti che lo richiedono. Documenta aperture intenzionali e limiti.
- Esporta il solo veicolo con le parti mobili necessarie. Reimporta il GLB in una scena isolata e confronta nodo radice, ingombri, posizioni, materiali, texture e numero di istanze. Quando il progetto richiede integrazione, verifica anche nel motore previsto.
- Renderizza dal sorgente finale sei viste a scala coerente, con entrambi i tre quarti più fronte, retro, lato e alto. Confrontale con il concept e guarda il veicolo anche alla dimensione di gioco. Controlla compenetrazioni, raccordi, asset sospesi e leggibilità dei materiali.
- Consegna sorgente, GLB, texture necessarie, viste e rapporto breve con conteggi e difetti residui. Tieni distinti audit tecnico, revisione visiva e approvazione dell’utente.
