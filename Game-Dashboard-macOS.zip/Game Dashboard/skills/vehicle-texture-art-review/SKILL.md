---
name: vehicle-texture-art-review
description: Valuta visivamente texture e materiali di veicoli rispetto a immagini approvate, con evidenze per area e giudizio indipendente. Usa per review artistiche e prove cieche; esclude modellazione, correzione degli asset e certificazione tecnica.
---

# Revisione artistica delle texture dei veicoli

Giudicare se il risultato raggiunge la qualita dei riferimenti nelle immagini fornite. Rimanere in sola lettura. Non modificare asset, skill, contatori, registri o immagini; restituire il giudizio al coordinatore. Una prova di calibrazione non autorizza a correggere i candidati o a cercarne l'esito atteso.

## Indipendenza e perimetro

Usare solo il pacchetto visivo, l'obiettivo artistico e i riferimenti forniti. Il pacchetto puo distinguere riferimenti positivi e controesempi negativi gia documentati: apprendere da entrambi le differenze visive, senza trasferire l'etichetta ai candidati in base al modello, colore o simbolo. Le etichette dei candidati restano sconosciute. Non cercare giudizi precedenti, manifest, nomi reali dei candidati o chiavi della prova. Se i candidati hanno codici neutri, mantenerli nel report. Valutare il trattamento delle superfici, non somiglianza della carrozzeria, palette identica, stessi simboli o quantita di ruggine uguale su tutti i modelli.

Il confronto tecnico e distinto. Hash, conservazione di geometria, pixel di una maschera, numero di mappe e shader funzionante non danno un PASS artistico. Se le immagini sono insufficienti, usare NON_VERIFICABILE e indicare la vista mancante. Non inventare limiti tecnici o un problema di UV senza evidenza visiva.

## Lettura del risultato

Applica i controlli su usura, ossido e danni quando l’obiettivo artistico o i riferimenti prevedono quelle finiture. Un veicolo pulito si valuta rispetto alla sua direzione visiva.

Guardare prima l'intero veicolo alla dimensione normale di presentazione, poi i dettagli e la scala di gioco quando disponibili. Per ogni area pertinente confrontare il candidato con almeno un riferimento appropriato:

- **Carrozzeria e vernice:** campiture leggibili con una finitura vissuta percepibile sul pannello. Campi integri sono legittimi; pannelli che restano quasi uniformi, con la sola presenza di poche grandi isole di danno, possono risultare insufficienti rispetto a riferimenti con variazioni di tinta, sfregamenti e transizioni articolate. Non considerare una finitura riuscita soltanto perche esiste in un atlante o si vede ingrandendo oltre la scala utile.
- **Danni e metalli:** variazioni di scala, margini fratturati, strati collegati di rivestimento/ossido/acciaio, differenze fra contatti, bordi e giunti. Grandi chiazze compatte simili a decalcomanie, contorni disegnati uniformi, metallo piatto o maculatura casuale possono impedire il PASS. Una quantita maggiore di ruggine non e un rimedio automatico.
- **Integrazione della grafica:** fasce, pannelli e contrassegni devono partecipare al trattamento del mezzo quando il riferimento lo richiede; una grafica pulita non e di per se un difetto, ma deve essere coerente con la finitura circostante. Valutare gerarchia e leggibilita, non preferenze personali su colori e numeri.
- **Altre classi visibili:** gomma, vetro e luci distinguibili dai metalli; nessuna usura stirata o motivo ripetuto evidente sulle superfici coinvolte. La geometria approvata non va riaperta in una review delle sole texture.

Schiarimenti a nuvola, piccoli nuclei pallidi a gessetto/frost, rumore continuo o macchie scollegate vanno confrontati nei dettagli pertinenti anche sulle tinte chiare. L'effetto gessetto puo essere localizzato e poco evidente nell'intero mezzo: gruppi minuti pallidi scollegati dal resto della finitura non diventano variazioni opache coerenti perche numerosi o poco contrastati. Distinguere questi nuclei dalle regioni piu continue dello stesso pigmento mostrate nei positivi. Non estendere il difetto alla geometria o a tutte le varianti dello stesso modello senza osservarle. Anche eliminarli lasciando nuovamente una superficie troppo uniforme puo essere insufficiente. Cercare la qualita dei passaggi nei riferimenti, non la sola assenza di una lista di errori.

## Campo di stile accettato

Usare l'insieme dei riferimenti come intervallo di soluzioni accettate, non imporre a tutti la tecnica di un solo esempio. Poche scrostature, segni angolari, fasce nitide o graffi direzionali non sono automaticamente difetti: confrontarne integrazione, gerarchia e scala con il positivo pertinente. Per rifiutare indicare il peggioramento visibile rispetto a quel campo di stile, senza scambiare una diversa carrozzeria o tecnica di disegno per un errore. La presenza di piu riferimenti non autorizza a giustificare qualsiasi risultato: motivare anche le differenze residue nelle aree deboli.

## Verdetto motivato

Per ciascun candidato riportare decisione, osservazioni per area, riferimento usato ed evidenza localizzabile (parte/vista). Separare fatti visibili, interpretazione e incertezza. Il motivo deve descrivere il risultato presente, non quanti controlli sono stati fatti o quanto e migliore della versione precedente.

PASS richiede una spiegazione positiva della coerenza delle aree pertinenti con i riferimenti, alla scala osservata. Un difetto correggibile ancora presente da CORREZIONE; evitare PASS con limiti. Se il coordinatore comunica che i tentativi sono esauriti, il difetto rimane NONRISOLTO: non diventa PASS e non autorizza una nuova iterazione.

Quando c'e una correzione, consolidare i difetti in una sola richiesta e nella verifica successiva rivalutare il veicolo intero. Nessuna zona e automaticamente approvata perche conservata dalla versione precedente o indicata come gia valida da un altro ruolo. Segnalare anche un disaccordo con un giudizio favorevole ricevuto accidentalmente.

Chiudere con un report breve per candidato: `decisione` (PASS/CORREZIONE/NON_VERIFICABILE), `aree`, `evidenze`, `confronto_con_riferimenti`, `correzione_consolidata`, `limiti`. L'approvazione dell'utente e sempre distinta dal verdetto interno. Nessuna modifica automatica al prodotto o al metodo.
