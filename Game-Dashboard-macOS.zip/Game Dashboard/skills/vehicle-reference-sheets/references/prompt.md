# Traccia per produrre una vista

Passa il concept originale del veicolo come riferimento visivo e dichiara il ruolo delle altre immagini. Per una correzione locale specifica vista, parte da cambiare e dettagli da conservare.

```text
Disegna lo stesso veicolo del concept allegato.
Silhouette e coda: [elementi effettivamente visibili].
Porte, finestrini e ruote: [conteggi, posizioni e asimmetrie].
Colori, materiali, piastre e usura: [elementi del concept].
Accessori e attacchi: [numero, orientamento e posizione].
Superfici senza riferimento diretto: [eventuale implicazione del concept o ipotesi dichiarata].

Produci la vista [ALTO / LATO / FRONTE / RETRO / TRE QUARTI].
Veicolo intero con margini chiari, senza scritte o guide.
Per alto e lato usa proiezione ortogonale e lo stesso verso.
Per fronte e retro segui l’asse centrale senza torsione.
Mantieni struttura, finitura, conteggi e attacchi in tutte le viste.
```
