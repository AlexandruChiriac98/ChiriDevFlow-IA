---
name: vehicle-reference-sheets
description: Crea e verifica tavole multivista di veicoli da concept esistenti, prima della modellazione 3D. Usa per preparare o correggere proiezioni, confrontare proporzioni e documentare parti ricostruite.
---

# Schede multivista dei veicoli

## Riferimenti e impaginazione

- Identifica il concept esatto del veicolo. Se proviene da una tavola, usa il ritaglio del solo veicolo richiesto e registra la cella o l’ID.
- Il concept determina silhouette, passo, sbalzi, numero di porte e ruote, attacchi, materiali, colori e asimmetrie. La tavola campione determina impaginazione e tipografia. Una revisione precedente dello stesso veicolo può aiutare a conservare i dettagli già risolti.
- Usa il formato approvato del progetto. In mancanza di un formato, prepara alto, lato, fronte e retro ortogonali più un tre quarti. Aggiungi il lato opposto quando serve a chiarire un’asimmetria.

## Produzione

- Se usi un generatore di immagini, fornisci direttamente il concept come riferimento visivo. Indica il ruolo di ogni altra immagine. Usa la [traccia pronta](references/prompt.md) per specificare le invarianti prima di generare una vista.
- Mantieni veicolo intero, scala confrontabile, sfondo neutro e assi coerenti. Orienta alto e lato nello stesso verso. Esegui ritagli e impaginazione con lo strumento disponibile. Conserva le viste singole se servono per la modellazione.
- Per una correzione locale indica la vista, la parte da cambiare e i dettagli già risolti. Se una superficie è occlusa nel concept, dichiara le ipotesi che introduci.

## Controlli e consegna

1. Confronta il tre quarti con il concept originale. Controlla lunghezze relative di cofano, abitacolo e coda, interasse, diametro delle ruote e impronta della sagoma.
2. Allinea le ortogonali a una scala comune usando punti fissi come assi delle ruote e linea di terra. Confronta muso, fine del tetto, ingombri, carreggiata e altezza. Verifica gli stessi punti da più viste.
3. Conta porte, montanti, fanali, prese e accessori visibili. Controlla forma, quota, orientamento e attacchi. Una presa si vede con la bocca in fronte e di fianco nel profilo. Conserva le asimmetrie senza duplicare gli elementi.
4. Verifica leggibilità di vetri, gomma, vernice e metalli. L’usura segue parti e contatti del concept quando richiesto.
5. Consegna la tavola, le eventuali viste separate e un riepilogo degli scarti e delle parti ricostruite. Verifica la leggibilità alle dimensioni finali. Le viste illustrate guidano la modellazione. Le quote precise richiedono riferimenti misurabili.
