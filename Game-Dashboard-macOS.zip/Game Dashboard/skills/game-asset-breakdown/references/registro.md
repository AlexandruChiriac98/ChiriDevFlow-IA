# Registro minimo

Riusa i file presenti; non imporre una migrazione di formato.

## Catalogo

- Reference: percorso, versione, hash, vincoli correnti e limiti dell'immagine.
- Voci: ID stabile, nome, categoria, tipo produttivo, evidenza/posizione, visibilità, varianti osservate/richieste/proposte, componenti da riusare, note.
- Una tabella leggibile e un JSON possono descrivere lo stesso catalogo; evita divergenze mantenendo una sola fonte strutturata quando possibile.

## Audit del secondo passaggio

- Zone dell'immagine ricontrollate e ID associati.
- Omissioni aggiunte, duplicati corretti e casi ancora incerti.
- Autore/metodo del controllo. Il controllo di ID e riferimenti non dimostra da solo la completezza visiva.

## Registro di produzione

Ogni lavoro è identificato dalla coppia ID + variante; più viste possono avere file distinti nello stesso lavoro.

```json
{
  "id": "P01",
  "variante": "integra",
  "versione": "v01",
  "stato": "generato-da-valutare",
  "reference": [{"percorso": "scene.png", "sha256": "..."}],
  "prompt_file": "prompt.json",
  "file": "P01-integra-v01.png",
  "sha256": "...",
  "controllo_tecnico": {"leggibile": true, "dimensioni": [480, 480], "alpha": true},
  "controllo_visivo": "soggetto e stile controllati; limiti annotati qui",
  "approvazione_utente": false
}
```

Usa `non-avviato`, `generato-da-valutare`, `da-correggere`, `approvato` e `scartato` o gli equivalenti già adottati. Un lotto ha un numero finito di lavori e un riepilogo dei restanti. Non marcare prodotte tutte le varianti di una voce quando esiste soltanto la base.

Per una copia ridotta registra file/hash della sorgente, metodo locale e dimensioni prima/dopo: non chiamarla nuova generazione. Per gli stati dinamici registra `non-necessario-dinamico` e rimuovili dai lavori pendenti. Conserva separatamente le composizioni illustrative richieste e le basi effettive da modellare.
