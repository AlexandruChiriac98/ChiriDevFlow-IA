---
name: game-asset-breakdown
description: Analizza concept o screenshot di videogiochi, compila e ricontrolla un inventario organizzato degli asset, aggiunge varianti e produce artwork individuali coerenti con la reference. Usa per scomporre una scena in asset; non per estrazione di mesh 3D o implementazione del gioco.
---

# Inventario e artwork degli asset

Applica nell'ordine: analisi immagine → lista organizzata → secondo controllo → varianti nella lista → artwork singoli → verifica e registro.

## 1. Riferimenti e inventario

- Individua l'immagine esatta e i riferimenti approvati del progetto; guarda le immagini prima di usarle. Conserva percorso, versione e SHA256 della scena di partenza.
- Leggi le decisioni correnti su stile, anatomia, proporzioni e UI. Non trasformare il layout di un concept in una disposizione di gioco approvata.
- Esamina la scena per zone, inclusi bordi, sfondo e HUD. Assegna un ID stabile a ogni asset distinto e raggruppa per funzione: personaggi, oggetti, macchinari, ambiente, decorazioni, segnaletica, UI.
- Per ogni voce indica nome, categoria, posizione/evidenza, stato visibile o incerto, componenti, riuso e note. Non contare ogni istanza ripetuta come nuovo asset.
- Distingui base, accessorio separabile, composizione di basi esistenti, materiale/decal, testo dinamico e componente UI. Non moltiplicare inutilmente artwork o mesh.
- Parti occluse/tagliate e oggetti ambigui restano espliciti. Una ricostruzione da immagine unica non è un'estrazione esatta e non dimostra retro, dimensioni o topologia.

## 2. Secondo controllo visivo

Riguarda l'immagine dopo la prima lista, in un passaggio distinto:

1. Immagine → lista: ricontrolla ogni zona cercando omissioni, soprattutto piccoli accessori, cartelli, supporti e HUD.
2. Lista → immagine: verifica l'evidenza di ogni voce; correggi duplicati, separazioni arbitrarie e oggetti inventati.
3. Registra zone ricontrollate, correzioni e dubbi residui. Non chiamare questa verifica revisione indipendente se l'ha fatta lo stesso agente.

## 3. Varianti e consegna della lista

- Per ciascuna base valuta forme/taglie, colori, stati funzionali, usura/danno e pose pertinenti. Separa varianti osservate, richieste dall'utente e proposte.
- Quando l'utente richiede forme diverse per ogni taglia, prepara sagome distinte entro ciascuna categoria: non limitarti a scalare lo stesso cuboide. Mantieni separati classe di gameplay, ingombro e forma; nuove proporzioni illustrative non sostituiscono automaticamente misure di modelli già approvate.
- Aggiungi le varianti alla voce corrispondente prima di iniziare gli artwork. Non promettere tutte le combinazioni teoricamente infinite: enumera opzioni utili o indica la regola parametrica.
- Colori, testi, riempimenti, rotazioni e combinazioni di componenti possono essere parametrici. Spiega quali richiedono realmente immagini distinte.
- Se il gioco prevede più lingue, separa scritte e dati localizzati da pannelli, icone e mesh. Conserva chiavi e traduzioni nei sorgenti del progetto, riusa la stessa grafica e controlla ingombri/leggibilità in ogni lingua prevista. Non incorporare testo dipendente dalla lingua in artwork raster quando può restare parametrico; aggiungi le versioni mancanti senza sovrascrivere quelle approvate e senza dedurne l'approvazione. Le lingue richieste e lo stato delle traduzioni appartengono al registro del progetto.
- Prima di produrre varianti, verifica se lo stato deriva da oggetti separati, fisica o logica di gioco. Non generare automaticamente cassoni/cestelli pieni, traboccanti o carrelli carichi se i contenuti verranno aggiunti dinamicamente: bastano contenitore vuoto e contenuti separati. Una composizione richiesta esplicitamente come reference resta distinta da un nuovo asset da modellare.
- Presenta prima l'inventario completo e i limiti. Se l'inventario è già stato consegnato e la produzione è autorizzata, riusalo e procedi senza ripetere richieste di conferma.
- L'approvazione della procedura non approva ogni variante proposta. Rispetta eventuali confini espressi dall'utente tra lista, selezione delle varianti e produzione.

## 4. Artwork individuali

- Per reference destinate a modelli low-poly limita il dettaglio a ciò che sarà modellato. Rispetta l'ultima scelta dell'utente sul formato: una risoluzione ridotta è un obiettivo solo se effettivamente controllabile. Se il tool non espone i pixel e l'utente richiede output nativo senza riduzioni, conserva l'originale generato: niente ridimensionamenti automatici né passaggi aggiunti solo per ottenere meno pixel.
- Prima di generare controlla se lo strumento espone davvero dimensioni/qualità. Dichiarare «480 px» nel prompt non garantisce quella risoluzione. Registra separatamente risoluzione richiesta, effettiva e dell'eventuale copia ridotta; non promettere risparmi di generazione da un semplice ridimensionamento successivo.
- Se l'utente sceglie esplicitamente di ridimensionare immagini esistenti, usa una riduzione locale senza nuove generazioni, conservando alpha, proporzioni, stile e originali. Non rigenerare un artwork approvato soltanto per ottenere meno pixel.
- Definisci un lotto limitato e dichiarato; quattro immagini è un valore pratico se il progetto non ne ha scelto uno diverso. Ogni variante effettiva occupa una voce del lotto.
- Riusa asset approvati disponibili; non ricreare il protagonista da una figura minuscola del concept quando esiste una reference canonica migliore.
- Mantieni riferimento di stile, camera, illuminazione, proporzioni e livello di dettaglio coerenti. Non aggiungere accessori o cambiamenti narrativi non richiesti.
- Usa lo strumento di generazione immagini disponibile per artwork raster. Una chiamata per asset/variante, con immagini di riferimento esplicite. Segui la skill imagegen quando disponibile. Per testi e UI geometriche parametriche preferisci i sorgenti vettoriali/codice già adottati dal progetto.
- Consegna un file per asset/variante. Un foglio con quattro oggetti può essere un riepilogo, non sostituisce i quattro file individuali.
- Per cutout richiedi vera trasparenza e conserva l'alpha. Non sostituire lo sfondo con una scacchiera disegnata. Nessun titolo, watermark o etichetta redazionale nell'immagine.
- Viste aggiuntive solo quando utili o richieste. Segnala le superfici ricostruite che l'immagine non mostra.
- Per asset modulari distingui segmento intermedio e terminale. Un intermedio deve mostrare estremi coerenti e raccordabili, profili longitudinali continui e supporti che non si duplicano sulla giunzione. Rulli di ritorno, paracolpi, pareti o risvolti terminali appartengono ai terminali, non al segmento da ripetere. Controlla anche che gli scivoli abbiano il percorso libero a ingresso/uscita. Un concept plausibile non certifica quote, agganci o trasporto già verificati nei modelli 3D.

## 5. Controllo, salvataggio e ripresa

- Guarda ogni output: soggetto corretto e unico, silhouette integra, stile, materiali, proporzioni e vincoli. Controlla separatamente file leggibile, dimensioni e alpha quando richiesto.
- Correggi in modo mirato i difetti materiali. Dopo due correzioni senza progresso, registra il limite e consegna con stato esplicito, senza dichiarare riuscito un vincolo fallito.
- Salva i file destinati al progetto nel workspace, con nomi ID-variante-versione. Conserva prompt effettivi, reference, SHA256 e stato di ciascuna consegna. Non sovrascrivere approvati.
- Distingui sempre generato, verificato tecnicamente, valutato visivamente dall'agente e approvato dall'utente. Un PNG non è un modello Blender/GLB né un asset già integrato nel motore.
- Per riprendere leggi solo i vincoli comuni, il lotto corrente e il registro: non riscrivere l'intero inventario a ogni gruppo. Ripeti l'analisi completa solo se cambia la scena o emergono omissioni rilevanti.
- Nel riepilogo attivo escludi le varianti superate o inutili per il funzionamento dinamico. Mantienile solo come storico esplicito, senza riproporle nella coda di produzione.

Per la struttura minima di catalogo, audit e registro consulta [references/registro.md](references/registro.md) quando devi creare nuovi file. Adatta i nomi allo schema esistente invece di duplicarlo.
