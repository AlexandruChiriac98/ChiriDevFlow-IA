import {
    api, h, icon, gameUrl, button, empty, nav, overview, projects, workflow,
    gameOverview, sectionView, connections, skills, entryFilterSuffix,
} from './views.js';
import { closeSelect, enhanceSelects } from './select.js';

const content = document.querySelector('#content');
const sidebar = document.querySelector('#sidebar');
const menu = document.querySelector('#mobile-menu');
const navigation = document.querySelector('#nav');
const crumb = document.querySelector('#crumb');
const dialog = document.querySelector('#dialog');
const dialogBody = document.querySelector('#dialog-body');
const notice = document.querySelector('#notice');
const pages = { overview: 'Panoramica', projects: 'Videogiochi', workflow: 'Workflow', connections: 'Connessioni IA', skills: 'Skill' };
let state;
let active;
let routeCount = 0;
let noticeTimer;
let entryUrlTimer;

function setMenu(open) {
    sidebar.classList.toggle('open', open);
    menu.setAttribute('aria-expanded', String(open));
}

function toast(message) {
    notice.textContent = message;
    clearTimeout(noticeTimer);
    noticeTimer = setTimeout(() => { notice.textContent = ''; }, 4000);
}

async function route({ refresh = false, focus = false } = {}) {
    clearTimeout(entryUrlTimer);
    const token = ++routeCount;
    const [path, query] = location.hash.slice(1).split('?', 2);
    const [view = 'overview', id, section = 'overview', selection] = path.split('/');
    if (!refresh) content.setAttribute('aria-busy', 'true');
    try {
        if (!state || refresh) state = await api('state');
        const isGame = view === 'game' && /^\d+$/.test(id);
        const game = isGame ? await api('project', { project: id }) : null;
        const selected = isGame
            ? [ ...Object.keys(state.sections), 'overview' ].includes(section) ? section : 'overview'
            : Object.hasOwn(pages, view) ? view : 'overview';
        let markup;
        let filter = '';
        if (game) {
            const category = game.categories.find(item => item.section === selected && item.id === Number(selection));
            filter = category?.id ?? (selection === 'senza-categoria' && Object.hasOwn(state.sections, selected) ? selection : '');
            const params = new URLSearchParams(query);
            const approval = params.get('approval');
            const entryFilters = {
                approval: Object.hasOwn(state.approvals, approval) ? approval : '',
                search: (params.get('q') ?? '').slice(0, 160),
            };
            markup = selected === 'overview' ? gameOverview(state, game) : sectionView(state, game, selected, filter, entryFilters);
        } else {
            markup = selected === 'connections' ? connections(await api('mcp'))
                : { overview, projects, workflow, skills }[selected](state);
        }
        if (token !== routeCount) return;
        active = { section: selected, data: game, filter };
        navigation.innerHTML = nav(state, game?.project, selected);
        crumb.innerHTML = game
            ? `<a href="#projects">Videogiochi</a>${icon('next')}<a class="project-crumb" href="${gameUrl(id)}">${h(game.project.name)}</a>
                ${selected === 'overview' ? '' : icon('next') + '<span>' + h(state.sections[selected]) + '</span>'}`
            : h(pages[selected]);
        closeSelect();
        content.innerHTML = markup;
        enhanceSelects(content);
        filterEntries();
        if (focus) {
            content.focus({ preventScroll: true });
            window.scrollTo(0, 0);
        }
    } catch (error) {
        if (token !== routeCount) return;
        active = null;
        if (state) navigation.innerHTML = nav(state, null, 'overview');
        content.innerHTML = empty('file', 'Pagina non disponibile', error.message, '<a class="button" href="#overview">Torna alla panoramica</a>');
    } finally {
        if (token === routeCount) content.removeAttribute('aria-busy');
    }
}

function dialogContent(title, body) {
    closeSelect();
    dialogBody.innerHTML = `<div class="dialog-head"><h2 id="dialog-title">${h(title)}</h2>
        <button class="icon-button" type="button" data-action="close" aria-label="Chiudi">${icon('close')}</button></div>${body}`;
    dialog.setAttribute('aria-labelledby', 'dialog-title');
    if (!dialog.open) dialog.showModal();
    dialog.scrollTop = 0;
}

function options(items, selected) {
    return items.map(item => `<option${item === selected ? ' selected' : ''}>${h(item)}</option>`).join('');
}

function form(title, fields, label, submit, extra = '') {
    dialogContent(title, `<form class="dialog-form">${fields}<p class="form-error" role="status"></p>
        <div class="dialog-actions">${extra}<button type="button" class="button" data-action="close">Annulla</button>
        <button class="button primary">${h(label)}</button></div></form>`);
    const element = dialogBody.querySelector('form');
    enhanceSelects(element);
    element.addEventListener('submit', async event => {
        event.preventDefault();
        const submitButton = element.querySelector('button:not([type])');
        const errorLine = element.querySelector('.form-error');
        submitButton.disabled = true;
        errorLine.textContent = '';
        try {
            await submit(new FormData(element));
        } catch (error) {
            errorLine.textContent = error.message;
        } finally {
            submitButton.disabled = false;
        }
    });
    return element;
}

function projectImportDialog(project) {
    const url = new URL(gameUrl(project.id), location.origin);
    const prompt = [
        `Leggi in locale la cartella «${project.folder_path}» e importa il lavoro nella scheda «${project.name}» (ID ${project.id}) di Game Dashboard. Apri ${url}.`,
        'Fai prima un inventario dei materiali effettivi. Usa le sezioni della scheda per separare artwork e concept, altre immagini, asset, modelli 3D, animazioni, funzionalità, regole e fonti. Riusa categorie e voci esistenti, evita duplicati e assegna uno stato di approvazione solo quando è documentato.',
        'Per ogni materiale usa «Aggiungi voce» e «File nella cartella di lavoro» per collegare l’originale mediante un percorso relativo. Inserisci i link web verificati nel campo Link. Salta credenziali, file nascosti, cache, build e dipendenze. Lascia intatti i file del gioco. Se puoi leggere i file ma non puoi usare la dashboard, prepara un inventario con i percorsi relativi. Se non puoi leggere i file, chiedimi di aprire una sessione locale.',
    ].join('\n\n');
    dialogContent('Importa il progetto con l’IA', `<div class="dialog-form">
        <p>La cartella è collegata. Per importare materiali e collegamenti, usa questo prompt in una sessione IA con accesso ai file del PC e alla dashboard locale.</p>
        <label>Prompt per l’IA<textarea rows="9" readonly>${h(prompt)}</textarea></label>
        <div class="dialog-actions"><button type="button" class="button" data-action="close">Chiudi</button>
        ${button('copy', 'Copia prompt', 'copy', `data-value="${h(prompt)}" data-copy-message="Prompt copiato."`, 'button primary')}</div></div>`);
}

function projectForm(project) {
    const element = form(project ? 'Modifica progetto' : 'Nuovo progetto', `
        <label>Nome del videogioco<input name="name" maxlength="70" required value="${h(project?.name)}"></label>
        <label>Genere o formato<input name="genre" maxlength="60" placeholder="Es. Platform · 2D" value="${h(project?.genre)}"></label>
        <div class="select-field"><label for="project-phase">Fase</label><select id="project-phase" name="phase">${options(state.phases, project?.phase)}</select></div>
        <label>Descrizione<textarea name="description" rows="4" maxlength="1200">${h(project?.description)}</textarea></label>
        <div class="select-field"><label for="project-folder-mode">Cartella di lavoro</label>
        <select id="project-folder-mode" name="folder_mode">
            <option value="create">Crea una cartella</option>
            <option value="link">Collega cartella esistente</option>
            <option value="keep"${project ? ' selected' : ''}>${project?.folder_path ? 'Mantieni cartella attuale' : 'Solo scheda'}</option>
        </select></div>
        <label data-folder-path>Percorso assoluto<input name="folder_path" maxlength="1024" autocomplete="off"
            spellcheck="false" placeholder="Incolla il percorso completo" aria-describedby="project-folder-help">
            <small id="project-folder-help" class="muted"></small></label>`,
    'Salva progetto', async fields => {
        const { id, folder_path } = await api('save-project', {}, { ...Object.fromEntries(fields), project: project?.id || 0 });
        dialog.close();
        await go(gameUrl(id));
        if (fields.get('folder_mode') === 'link') {
            projectImportDialog({ id, name: fields.get('name').trim(), folder_path });
        } else {
            toast('Progetto salvato.');
        }
    });
    const mode = element.elements.folder_mode;
    const path = element.elements.folder_path;
    const help = element.querySelector('#project-folder-help');
    function updateFolderField() {
        const needsPath = mode.value !== 'keep';
        path.closest('[data-folder-path]').hidden = !needsPath;
        path.required = needsPath;
        path.disabled = !needsPath;
        help.textContent = mode.value === 'create'
            ? 'Inserisci il percorso completo della nuova cartella, incluso il suo nome. La cartella superiore deve esistere.'
            : 'Copia il percorso completo della cartella del gioco. Dopo il salvataggio vedrai il prompt per importarla con l’IA.';
    }
    mode.addEventListener('change', updateFolderField);
    updateFolderField();
}

function entryForm(entry) {
    const { data, section, filter } = active;
    const categoryOptions = (targetSection, selected) => '<option value="">Senza categoria</option>'
        + data.categories.filter(category => category.section === targetSection).map(category =>
            `<option value="${category.id}" ${category.id === selected ? 'selected' : ''}>${h(category.name)}</option>`).join('');
    const category = entry ? entry.category_id : filter;
    form(entry ? 'Modifica voce' : 'Aggiungi voce', `
        <label>Titolo<input name="title" maxlength="100" required value="${h(entry?.title)}"></label>
        <div class="select-field"><label for="entry-section">Sezione</label><select id="entry-section" name="section">${Object.entries(state.sections).map(([key, label]) =>
            `<option value="${key}" ${key === section ? 'selected' : ''}>${h(label)}</option>`).join('')}</select></div>
        <div class="select-field"><label for="entry-category">Categoria</label>
        <select id="entry-category" name="category_id">${categoryOptions(section, category)}</select></div>
        <div class="select-field"><label for="entry-status">Stato</label><select id="entry-status" name="status">${options(state.statuses, entry?.status)}</select></div>
        <div class="select-field"><label for="entry-approval">Approvazione</label>
        <select id="entry-approval" name="approval">${Object.entries(state.approvals).map(([key, label]) =>
            `<option value="${key}" ${key === (entry?.approval ?? 'review') ? 'selected' : ''}>${h(label)}</option>`).join('')}</select></div>
        <label>Note<textarea name="notes" rows="4" maxlength="4000">${h(entry?.notes)}</textarea></label>
        <label>Link facoltativo<input type="url" name="url" maxlength="2000" value="${h(entry?.url)}"></label>
        ${data.project.folder_path ? `<label>File nella cartella di lavoro<input name="local_file" maxlength="1024" placeholder="Es. Assets/Auto.glb" spellcheck="false">
            <small class="muted">Collega l’originale con il percorso relativo alla cartella di lavoro.</small></label>` : ''}
        <label>${entry?.filename ? `Sostituisci ${h(entry.filename)}` : 'Allegato facoltativo (max 20 MB)'}
            <input type="file" name="attachment"></label>`,
    'Salva voce', async fields => {
        fields.set('project', data.project.id);
        if (entry) fields.set('id', entry.id);
        await api('save-entry', {}, fields);
        dialog.close();
        const targetCategory = fields.get('category_id');
        await go(gameUrl(data.project.id, fields.get('section'), targetCategory || (filter === 'senza-categoria' ? filter : '')));
        toast('Voce salvata.');
    }, entry ? button('remove-entry', 'Elimina', 'close', `data-id="${entry.id}"`, 'button danger') : '');
    const sectionField = dialogBody.querySelector('#entry-section');
    sectionField.addEventListener('change', () => {
        const categoryField = dialogBody.querySelector('#entry-category');
        categoryField.innerHTML = categoryOptions(sectionField.value, sectionField.value === section ? category : null);
        enhanceSelects(dialogBody);
    });
    dialogBody.querySelector('input[name="attachment"]').addEventListener('change', event => {
        if (!event.target.files.length) return;
        dialogBody.querySelector('#entry-approval').value = 'review';
        enhanceSelects(dialogBody);
    });
}

function categoryForm(category) {
    const { data, section } = active;
    const { project } = data;
    form(category ? 'Rinomina categoria' : 'Aggiungi categoria', `
        <p class="muted">${h(state.sections[section])} · ${h(project.name)}</p>
        <label>Nome della categoria<input name="name" maxlength="60" required value="${h(category?.name)}" placeholder="Es. Menu UI"></label>`,
    'Salva categoria', async fields => {
        const { id } = await api('save-category', {}, { project: project.id, section, id: category?.id, name: fields.get('name') });
        dialog.close();
        await go(gameUrl(project.id, section, id));
        toast('Categoria salvata.');
    }, category ? button('remove-category', 'Elimina categoria', 'trash', '', 'button danger') : '');
}

function removeCategory() {
    const { data, section, filter } = active;
    const category = data.categories.find(item => item.id === filter && item.section === section);
    if (!category) return;
    const project = data.project.id;
    const hasEntries = data.entries.some(entry => entry.category_id === category.id);
    form('Elimina categoria',
        `<p>Eliminare <strong>${h(category.name)}</strong>?</p>
        ${hasEntries ? '<p class="muted">Le voci e gli allegati restano nella sezione sotto <strong>Senza categoria</strong>.</p>' : ''}`,
        'Elimina categoria', async () => {
            await api('remove-category', {}, { project, section, id: category.id });
            dialog.close();
            await go(gameUrl(project, section, hasEntries ? 'senza-categoria' : ''));
            toast('Categoria eliminata.');
        });
    dialogBody.querySelector('form [data-action="close"]').focus();
}

async function go(hash) {
    if (location.hash !== hash) history.pushState(null, '', hash);
    await route({ refresh: true, focus: true });
}

function searchDialog() {
    const games = state.projects;
    dialogContent('Cerca progetti', `<div class="search-dialog"><label>Nome o genere<input type="search" id="project-search"
        autocomplete="off" autofocus placeholder="Cerca nel workspace…"></label><div id="search-results"></div></div>`);
    const input = dialogBody.querySelector('input');
    const results = dialogBody.querySelector('#search-results');
    const filter = () => {
        const needle = input.value.trim().toLowerCase();
        const matches = games.filter(game => `${game.name} ${game.genre}`.toLowerCase().includes(needle));
        results.innerHTML = matches.length ? matches.map(game => `<a class="search-result" href="${gameUrl(game.id)}" data-action="close">
            ${icon('game')}<span>${h(game.name)}<small>${h(game.archived ? 'Archiviato' : game.phase)}</small></span>${icon('next')}</a>`).join('')
            : '<p class="muted">Nessun progetto corrispondente.</p>';
    };
    input.addEventListener('input', filter);
    input.focus();
    filter();
}

document.addEventListener('click', async event => {
    const trigger = event.target.closest('[data-action]');
    if (!trigger) return;
    const action = trigger.dataset.action;
    if (action === 'close') return dialog.close();
    if (!state) return;
    try {
        switch (action) {
            case 'search': return searchDialog();
            case 'new-project': return projectForm();
            case 'edit-project': return projectForm(active.data.project);
            case 'import-project': return projectImportDialog(active.data.project);
            case 'new-entry': return entryForm();
            case 'edit-entry': return entryForm(active.data.entries.find(entry => entry.id === Number(trigger.dataset.id)));
            case 'new-category': return categoryForm();
            case 'edit-category': return categoryForm(active.data.categories.find(category => category.id === active.filter));
            case 'remove-category': return removeCategory();
            case 'archive':
                trigger.disabled = true;
                await api('archive', {}, { project: active.data.project.id });
                return route({ refresh: true });
            case 'remove-entry':
                if (!confirm('Eliminare questa voce e il suo allegato?')) return;
                await api('remove-entry', {}, { project: active.data.project.id, id: Number(trigger.dataset.id) });
                dialog.close();
                await route({ refresh: true });
                return toast('Voce eliminata.');
            case 'copy':
                await navigator.clipboard.writeText(trigger.dataset.value);
                return toast(trigger.dataset.copyMessage || 'Comando copiato.');
        }
    } catch (error) {
        trigger.disabled = false;
        const errorLine = dialog.open && dialog.querySelector('.form-error');
        if (errorLine) errorLine.textContent = error.message;
        else toast(error.message);
    }
});

const normaliseSearch = value => value.normalize('NFD').replace(/\p{M}/gu, '').toLocaleLowerCase('it').replace(/\s+/g, ' ');

function filterEntries(updateUrl = false) {
    const searchField = content.querySelector('#entry-search');
    if (!searchField) return;
    const search = searchField.value;
    const needle = normaliseSearch(search.trim());
    const approval = content.querySelector('[data-approval-filter][aria-pressed="true"]').dataset.approvalFilter;
    const entries = content.querySelectorAll('.entry');
    let matches = 0;
    for (const entry of entries) {
        const text = normaliseSearch(entry.dataset.search);
        entry.hidden = (approval !== '' && entry.dataset.approval !== approval) || !text.includes(needle);
        if (!entry.hidden) matches++;
    }
    content.querySelector('.entry-result-count').textContent = matches === 1 ? '1 voce' : `${matches} voci`;
    content.querySelector('.entry-search-empty').hidden = entries.length === 0 || matches !== 0;
    if (updateUrl) {
        const suffix = entryFilterSuffix({ approval, search });
        const from = location.hash;
        const target = from.split('?')[0] + suffix;
        clearTimeout(entryUrlTimer);
        entryUrlTimer = setTimeout(() => {
            if (location.hash === from && from !== target) history.replaceState(history.state, '', target);
        }, 220);
        for (const link of content.querySelectorAll('a.category-link')) {
            link.setAttribute('href', link.getAttribute('href').split('?')[0] + suffix);
        }
    }
}

content.addEventListener('input', event => {
    if (event.target.id === 'entry-search') filterEntries(true);
});

content.addEventListener('click', event => {
    const selected = event.target.closest('[data-approval-filter]');
    if (!selected) return;
    for (const control of content.querySelectorAll('[data-approval-filter]')) {
        control.setAttribute('aria-pressed', String(control === selected));
    }
    filterEntries(true);
});

menu.addEventListener('click', () => setMenu(!sidebar.classList.contains('open')));
dialog.addEventListener('close', closeSelect);
navigation.addEventListener('click', event => { if (event.target.closest('a')) setMenu(false); });
document.querySelector('.skip').addEventListener('click', event => { event.preventDefault(); content.focus(); });
document.addEventListener('keydown', event => {
    if (event.defaultPrevented) return;
    if (event.key === 'Escape') setMenu(false);
    if (event.key === '/' && state && !dialog.open && !event.target.matches('input,select,textarea,[contenteditable]')) {
        event.preventDefault();
        searchDialog();
    }
});
window.addEventListener('hashchange', () => { setMenu(false); route({ focus: true }); });
route();
