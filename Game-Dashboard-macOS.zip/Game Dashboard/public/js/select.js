const controls = new WeakMap();
let active;

export function closeSelect() {
    if (!active) return;
    const control = active;
    active = null;
    control.menu.hidePopover();
    control.button.setAttribute('aria-expanded', 'false');
    control.button.removeAttribute('aria-activedescendant');
}

function highlight(control, index, scroll = true) {
    const item = control.menu.children[index];
    if (!item || control.select.options[index].disabled) return;
    control.menu.children[control.index]?.classList.remove('is-active');
    control.index = index;
    item.classList.add('is-active');
    control.button.setAttribute('aria-activedescendant', item.id);
    if (scroll) {
        if (item.offsetTop < control.menu.scrollTop) control.menu.scrollTop = item.offsetTop;
        const bottom = item.offsetTop + item.offsetHeight;
        if (bottom > control.menu.scrollTop + control.menu.clientHeight) {
            control.menu.scrollTop = bottom - control.menu.clientHeight;
        }
    }
}

function sync(control) {
    if (active === control) closeSelect();
    const { select, button, value, menu } = control;
    button.disabled = select.disabled;
    value.textContent = select.selectedOptions[0]?.textContent || 'Seleziona';
    menu.replaceChildren(...Array.from(select.options, (option, index) => {
        const item = document.createElement('div');
        item.id = menu.id + '-' + index;
        item.className = 'select-option';
        item.dataset.index = index;
        item.setAttribute('role', 'option');
        item.setAttribute('aria-selected', String(option.selected));
        item.setAttribute('aria-disabled', String(option.disabled));
        item.textContent = option.textContent;
        return item;
    }));
}

function openSelect(control) {
    closeSelect();
    if (control.select.disabled || !control.select.options.length) return;
    active = control;
    control.search = '';
    control.button.setAttribute('aria-expanded', 'true');
    control.menu.showPopover();
    placeSelect(control);
    if (active === control) highlight(control, control.select.selectedIndex);
}

function placeSelect(control) {
    const rect = control.button.getBoundingClientRect();
    const viewport = window.visualViewport;
    const edge = 8;
    const gap = 6;
    const top = viewport?.offsetTop ?? 0;
    const left = viewport?.offsetLeft ?? 0;
    const width = Math.min(rect.width, (viewport?.width ?? innerWidth) - 2 * edge);
    const right = left + (viewport?.width ?? innerWidth);
    const bottom = top + (viewport?.height ?? innerHeight);
    if (rect.bottom <= top || rect.top >= bottom) {
        closeSelect();
        return;
    }
    const below = bottom - rect.bottom - gap - edge;
    const above = rect.top - top - gap - edge;
    const upwards = below < Math.min(260, control.menu.scrollHeight) && above > below;
    Object.assign(control.menu.style, {
        left: Math.max(left + edge, Math.min(rect.left, right - width - edge)) + 'px',
        width: width + 'px',
        maxHeight: Math.max(0, Math.min(280, upwards ? above : below)) + 'px',
    });
    control.menu.style.top = (upwards ? rect.top - gap - control.menu.offsetHeight : rect.bottom + gap) + 'px';
}

function choose(control, index) {
    const option = control.select.options[index];
    if (!option || option.disabled) return;
    const changed = control.select.selectedIndex !== index;
    control.select.selectedIndex = index;
    closeSelect();
    if (changed) control.select.dispatchEvent(new Event('change', { bubbles: true }));
    control.button.focus({ preventScroll: true });
}

function selectKey(event, control) {
    const { key } = event;
    const isOpen = active === control;
    if (key === 'Tab') {
        closeSelect();
        return;
    }
    if (key === 'Escape' && isOpen) {
        event.preventDefault();
        event.stopPropagation();
        closeSelect();
        return;
    }
    if (key === 'Enter' || key === ' ') {
        event.preventDefault();
        if (isOpen) choose(control, control.index);
        else openSelect(control);
        return;
    }

    const steps = { ArrowDown: 1, ArrowUp: -1, PageDown: 5, PageUp: -5 };
    const options = Array.from(control.select.options);
    if (Object.hasOwn(steps, key) || key === 'Home' || key === 'End') {
        event.preventDefault();
        if (!isOpen) {
            openSelect(control);
            if (key === 'ArrowUp' || key === 'ArrowDown') return;
        }
        const fromStart = key === 'Home';
        const fromEnd = key === 'End';
        const start = fromStart ? 0 : fromEnd ? options.length - 1 : control.index + steps[key];
        const direction = fromStart ? 1 : fromEnd ? -1 : Math.sign(steps[key]);
        let index = Math.max(0, Math.min(options.length - 1, start));
        while (options[index]?.disabled) index += direction;
        highlight(control, index);
        return;
    }

    if (key.length !== 1 || event.ctrlKey || event.metaKey || event.altKey) return;
    event.preventDefault();
    if (!isOpen) openSelect(control);
    const now = Date.now();
    control.search = (now - control.searchTime > 700 ? '' : control.search) + key.toLocaleLowerCase('it');
    control.searchTime = now;
    const chars = [...control.search];
    const needle = chars.every(char => char === chars[0]) ? chars[0] : control.search;
    for (let offset = 1; offset <= options.length; offset++) {
        const index = (Math.max(control.index, 0) + offset) % options.length;
        if (!options[index].disabled && options[index].textContent.toLocaleLowerCase('it').startsWith(needle)) {
            highlight(control, index);
            break;
        }
    }
}

function createControl(select) {
    const label = select.labels[0];
    const wrapper = document.createElement('div');
    wrapper.className = 'select-control';
    const button = document.createElement('button');
    button.type = 'button';
    button.id = select.id + '-control';
    button.className = 'select-trigger';
    button.setAttribute('role', 'combobox');
    button.setAttribute('aria-haspopup', 'listbox');
    button.setAttribute('aria-expanded', 'false');
    if (select.required) button.setAttribute('aria-required', 'true');
    const value = document.createElement('span');
    value.id = select.id + '-value';
    button.append(value);
    const menu = document.createElement('div');
    menu.className = 'select-menu';
    menu.id = select.id + '-options';
    menu.setAttribute('role', 'listbox');
    menu.setAttribute('popover', 'manual');
    button.setAttribute('aria-controls', menu.id);
    if (label) {
        label.id ||= select.id + '-label';
        label.htmlFor = button.id;
        button.setAttribute('aria-labelledby', label.id + ' ' + value.id);
        menu.setAttribute('aria-labelledby', label.id);
    }
    select.after(wrapper);
    select.hidden = true;
    wrapper.append(button, menu);
    const control = { select, wrapper, button, value, menu, index: -1, search: '', searchTime: 0 };
    button.addEventListener('click', () => active === control ? closeSelect() : openSelect(control));
    button.addEventListener('keydown', event => selectKey(event, control));
    select.addEventListener('change', () => sync(control));
    select.addEventListener('invalid', event => {
        event.preventDefault();
        button.focus();
    });
    menu.addEventListener('pointerdown', event => {
        if (event.pointerType === 'mouse') event.preventDefault();
    });
    menu.addEventListener('pointermove', event => {
        const item = event.target.closest('[role=option]');
        if (item && event.pointerType === 'mouse') highlight(control, Number(item.dataset.index), false);
    });
    menu.addEventListener('click', event => {
        const item = event.target.closest('[role=option]');
        if (item) choose(control, Number(item.dataset.index));
    });
    return control;
}

export function enhanceSelects(root) {
    if (!HTMLElement.prototype.showPopover) return;
    for (const select of root.querySelectorAll('select')) {
        const control = controls.get(select) || createControl(select);
        controls.set(select, control);
        sync(control);
    }
}

document.addEventListener('pointerdown', event => {
    if (active && !active.wrapper.contains(event.target)) closeSelect();
});
document.addEventListener('scroll', event => {
    if (!active || active.menu.contains(event.target)) return;
    placeSelect(active);
}, true);
window.addEventListener('resize', () => { if (active) placeSelect(active); });
window.visualViewport?.addEventListener('resize', () => { if (active) placeSelect(active); });
