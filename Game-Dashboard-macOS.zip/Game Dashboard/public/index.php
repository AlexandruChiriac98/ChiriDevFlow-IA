<?php
declare(strict_types=1);

$peer = $_SERVER['REMOTE_ADDR'] ?? '';
$host = $_SERVER['HTTP_HOST'] ?? '';
if (PHP_SAPI !== 'cli-server' || !in_array($peer, ['127.0.0.1', '::1'], true)
    || !preg_match('/^(127\.0\.0\.1|localhost)(:[0-9]{1,5})?$/D', $host)) {
    http_response_code(403);
    exit;
}
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
if (preg_match('~^/(?:css/[a-z-]+\.css|js/[a-z-]+\.js|media/[a-z-]+\.(?:webp|png)|favicon\.ico|downloads/game-dashboard-skills\.zip)$~D', $path)
    && is_file(__DIR__ . $path)) {
    return false;
}
if ($path === '/health') {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode([
        'app' => 'ilchiridev-game-workflow',
        'instance' => str_replace('\\', '/', dirname(__DIR__)),
        'pid' => getmypid(),
    ], JSON_THROW_ON_ERROR);
    return true;
}
if ($path !== '/' && $path !== '/api') {
    http_response_code(404);
    exit;
}

header("Content-Security-Policy: default-src 'self'; img-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header('Cache-Control: no-store');
ini_set('display_errors', '0');
session_name('IlChiriWorkflow');
session_start(['cookie_httponly' => true, 'cookie_samesite' => 'Strict', 'use_strict_mode' => true]);
$csrf = $_SESSION['csrf'] ??= bin2hex(random_bytes(32));

if ($path === '/api') {
    require dirname(__DIR__) . '/src/store.php';
    require dirname(__DIR__) . '/src/api.php';
    handleApi((string) ($_GET['action'] ?? ''), $csrf);
}
session_write_close();
require dirname(__DIR__) . '/src/page.php';
