<?php
declare(strict_types=1);

const SECTIONS = [
    'artwork' => 'Artwork e concept',
    'images' => 'Altre immagini',
    'assets' => 'Asset',
    'models' => 'Modelli 3D',
    'animations' => 'Animazioni',
    'features' => 'Funzionalità',
    'rules' => 'Regole di gioco',
    'sources' => 'Fonti e inventario',
];
const PHASES = ['Briefing', 'Prototipo', 'Concept / Produzione', 'Playtest', 'Pubblicato'];
const STATUSES = ['Da fare', 'In corso', 'Da rivedere', 'Completato'];
const APPROVALS = ['approved' => 'Approvato', 'rejected' => 'Non approvato', 'review' => 'Da rivedere'];

final class InputError extends RuntimeException {}

function workflowDataDir(): string
{
    return getenv('GAME_WORKFLOW_DATA_DIR') ?: dirname(__DIR__) . '/var';
}

function database(): PDO
{
    $dir = workflowDataDir();
    if (!is_dir($dir) && !mkdir($dir, 0700, true) && !is_dir($dir)) {
        throw new RuntimeException('Impossibile creare la cartella dati.');
    }
    $db = new PDO('sqlite:' . $dir . '/workflow.sqlite');
    $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $db->exec('PRAGMA busy_timeout=5000; PRAGMA foreign_keys=ON');
    if ((int) $db->query('PRAGMA user_version')->fetchColumn() >= 7) {
        return $db;
    }
    atomic($db, function () use ($db): void {
        $version = (int) $db->query('PRAGMA user_version')->fetchColumn();
        if ($version >= 7) {
            return;
        }
        if ($version === 0) {
            $db->exec("
                CREATE TABLE projects (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, genre TEXT NOT NULL,
                    description TEXT NOT NULL, phase TEXT NOT NULL, cover TEXT, archived INTEGER NOT NULL DEFAULT 0
                );
                CREATE TABLE entries (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL REFERENCES projects(id),
                    section TEXT NOT NULL, title TEXT NOT NULL, notes TEXT NOT NULL, status TEXT NOT NULL,
                    url TEXT NOT NULL DEFAULT '', filename TEXT, mime TEXT, attachment BLOB
                );
                CREATE INDEX entries_project ON entries(project_id, section);
            ");
        }
        if ($version < 2) {
            $db->exec("
                CREATE TABLE linked_attachments (
                    entry_id INTEGER PRIMARY KEY REFERENCES entries(id) ON DELETE CASCADE,
                    root TEXT NOT NULL,
                    relative_path TEXT NOT NULL
                );
            ");
        }
        if ($version < 3) {
            $db->exec("
                CREATE TABLE categories (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    project_id INTEGER NOT NULL REFERENCES projects(id),
                    section TEXT NOT NULL,
                    name TEXT NOT NULL,
                    name_key TEXT NOT NULL,
                    UNIQUE(project_id, section, name_key)
                );
                ALTER TABLE entries ADD COLUMN category_id INTEGER REFERENCES categories(id) ON DELETE SET NULL;
            ");
        }
        if ($version < 4) {
            $db->exec("
                ALTER TABLE entries ADD COLUMN approval TEXT NOT NULL DEFAULT 'review'
                    CHECK (approval IN ('approved','rejected','review'));
            ");
        }
        if ($version < 5) {
            $db->exec("
                ALTER TABLE projects ADD COLUMN revision INTEGER NOT NULL DEFAULT 1;
                CREATE TRIGGER project_context_update AFTER UPDATE OF name,genre,description,phase,cover,archived ON projects
                WHEN OLD.name IS NOT NEW.name OR OLD.genre IS NOT NEW.genre OR OLD.description IS NOT NEW.description
                    OR OLD.phase IS NOT NEW.phase OR OLD.cover IS NOT NEW.cover OR OLD.archived IS NOT NEW.archived
                BEGIN UPDATE projects SET revision=revision+1 WHERE id=NEW.id; END;
                CREATE TRIGGER entry_context_insert AFTER INSERT ON entries
                BEGIN UPDATE projects SET revision=revision+1 WHERE id=NEW.project_id; END;
                CREATE TRIGGER entry_context_delete AFTER DELETE ON entries
                BEGIN UPDATE projects SET revision=revision+1 WHERE id=OLD.project_id; END;
                CREATE TRIGGER entry_context_update AFTER UPDATE OF project_id,section,title,notes,status,category_id,approval,filename ON entries
                WHEN OLD.project_id IS NOT NEW.project_id OR OLD.section IS NOT NEW.section OR OLD.title IS NOT NEW.title
                    OR OLD.notes IS NOT NEW.notes OR OLD.status IS NOT NEW.status OR OLD.category_id IS NOT NEW.category_id
                    OR OLD.approval IS NOT NEW.approval OR OLD.filename IS NOT NEW.filename
                BEGIN UPDATE projects SET revision=revision+1 WHERE id IN (OLD.project_id,NEW.project_id); END;
                CREATE TRIGGER category_context_insert AFTER INSERT ON categories
                BEGIN UPDATE projects SET revision=revision+1 WHERE id=NEW.project_id; END;
                CREATE TRIGGER category_context_delete AFTER DELETE ON categories
                BEGIN UPDATE projects SET revision=revision+1 WHERE id=OLD.project_id; END;
                CREATE TRIGGER category_context_update AFTER UPDATE OF name ON categories WHEN OLD.name IS NOT NEW.name
                BEGIN UPDATE projects SET revision=revision+1 WHERE id=NEW.project_id; END;
            ");
        }
        if ($version < 6) {
            $db->exec("UPDATE projects SET phase='Concept / Produzione' WHERE phase IN ('Concept','Produzione')");
        }
        $db->exec("
            ALTER TABLE projects ADD COLUMN folder_path TEXT;
            CREATE TRIGGER project_folder_update AFTER UPDATE OF folder_path ON projects
            WHEN OLD.folder_path IS NOT NEW.folder_path
            BEGIN UPDATE projects SET revision=revision+1 WHERE id=NEW.id; END;
            PRAGMA user_version=7;
        ");
    });
    return $db;
}

function atomic(PDO $db, callable $action): mixed
{
    $db->exec('BEGIN IMMEDIATE');
    try {
        $result = $action();
        $db->exec('COMMIT');
        return $result;
    } catch (Throwable $e) {
        $db->exec('ROLLBACK');
        throw $e;
    }
}

function query(PDO $db, string $sql, array $values = []): PDOStatement
{
    $statement = $db->prepare($sql);
    $statement->execute($values);
    return $statement;
}

function getProject(PDO $db, int $id): array
{
    $project = query($db, 'SELECT * FROM projects WHERE id=?', [$id])->fetch();
    if (!$project) {
        throw new InputError('Progetto non trovato.');
    }
    return $project;
}

function projectFolderPath(string $path): string
{
    if (str_starts_with($path, '"') && str_ends_with($path, '"')) {
        $path = substr($path, 1, -1);
    }
    $windows = PHP_OS_FAMILY === 'Windows';
    $path = $windows ? str_replace('\\', '/', $path) : $path;
    $pattern = $windows ? '~^[a-z]:/[^:]+$~iD' : '~^/[^/].*$~D';
    if (!preg_match($pattern, $path) || preg_match('/[\x00-\x1f\x7f]/', $path)
        || preg_match('~(?:^|/)\.{1,2}(?:/|$)~', $path)) {
        throw new InputError('Inserisci il percorso assoluto di una cartella del progetto.');
    }
    return rtrim($path, '/');
}

function saveProject(PDO $db, int $id, array $body): array
{
    $fields = [value($body, 'name', 70, true), value($body, 'genre', 60), value($body, 'description', 1200),
        choice(value($body, 'phase', 20), PHASES)];
    $mode = choice(value($body, 'folder_mode', 12) ?: 'keep', ['keep', 'create', 'link']);
    $path = $mode === 'keep' ? null : projectFolderPath(value($body, 'folder_path', 1024, true));
    $created = null;
    try {
        return atomic($db, function () use ($db, $id, $fields, $mode, $path, &$created): array {
            $previous = $id ? getProject($db, $id) : null;
            $folder = $previous['folder_path'] ?? null;
            if ($mode === 'create') {
                $parent = realpath(dirname($path));
                if ($parent === false || !is_dir($parent)) {
                    throw new InputError('La cartella superiore deve già esistere.');
                }
                $name = basename($path);
                if (PHP_OS_FAMILY === 'Windows' && (preg_match('/[<>"|?*]/', $name) || rtrim($name, ' .') !== $name)) {
                    throw new InputError('Il nome della cartella non è valido su Windows.');
                }
                $target = rtrim($parent, '/\\') . DIRECTORY_SEPARATOR . $name;
                if (file_exists($target) || is_link($target)) {
                    throw new InputError('Quel percorso esiste già. Usa «Collega cartella esistente».');
                }
                if (!@mkdir($target, 0700)) {
                    throw new InputError('Impossibile creare la cartella nel percorso indicato.');
                }
                $created = $target;
                $folder = $target;
            } elseif ($mode === 'link') {
                $folder = realpath($path);
                if ($folder === false || !is_dir($folder) || !is_readable($folder)) {
                    throw new InputError('La cartella indicata non esiste o non è accessibile.');
                }
            }
            if ($id) {
                query($db, 'UPDATE projects SET name=?,genre=?,description=?,phase=?,folder_path=? WHERE id=?',
                    [...$fields, $folder, $id]);
            } else {
                query($db, 'INSERT INTO projects(name,genre,description,phase,folder_path) VALUES(?,?,?,?,?)', [...$fields, $folder]);
                $id = (int) $db->lastInsertId();
            }
            return ['id' => $id, 'folder_path' => $folder];
        });
    } catch (Throwable $error) {
        if ($created !== null) {
            @rmdir($created);
        }
        throw $error;
    }
}

function linkedAttachmentPath(string $root, string $relative): ?string
{
    $relative = str_replace('\\', '/', $relative);
    if ($relative === '' || preg_match('/[:\x00-\x1f\x7f]/', $relative)) {
        return null;
    }
    foreach (explode('/', $relative) as $part) {
        if ($part === '' || str_starts_with($part, '.')) {
            return null;
        }
    }
    $normalise = static fn (string $path): string => rtrim(str_replace('\\', '/', $path), '/');
    $expected = $normalise($root) . '/' . $relative;
    $real = realpath($expected);
    if ($real === false || !is_file($real)) {
        return null;
    }
    $resolved = $normalise($real);
    $matches = PHP_OS_FAMILY === 'Windows' ? strcasecmp($expected, $resolved) === 0 : $expected === $resolved;
    return $matches ? $real : null;
}

function projectEntries(PDO $db, int $id): array
{
    return query($db, 'SELECT id,section,title,notes,status,url,filename,mime,category_id,approval
        FROM entries WHERE project_id=? ORDER BY id DESC', [$id])->fetchAll();
}

function projectCategories(PDO $db, int $project): array
{
    return query($db, 'SELECT id,section,name FROM categories WHERE project_id=? ORDER BY id', [$project])->fetchAll();
}

function saveCategory(PDO $db, int $project, array $body): int
{
    $id = (int) ($body['id'] ?? 0);
    $section = choice(value($body, 'section', 30), array_keys(SECTIONS));
    $name = trim(preg_replace('/\s+/u', ' ', value($body, 'name', 60, true)));
    if ($name === '') {
        throw new InputError('Inserisci il nome della categoria.');
    }
    $key = mb_strtolower($name, 'UTF-8');
    return atomic($db, function () use ($db, $project, $section, $id, $name, $key): int {
        $duplicate = query($db, 'SELECT id FROM categories WHERE project_id=? AND section=? AND name_key=? AND id<>?',
            [$project, $section, $key, $id])->fetchColumn();
        if ($duplicate) {
            throw new InputError('In questa sezione esiste già una categoria con questo nome.');
        }
        if ($id) {
            $changed = query($db, 'UPDATE categories SET name=?,name_key=? WHERE id=? AND project_id=? AND section=?',
                [$name, $key, $id, $project, $section])->rowCount();
            if (!$changed) {
                throw new InputError('Categoria non trovata.');
            }
            return $id;
        }
        query($db, 'INSERT INTO categories(project_id,section,name,name_key) VALUES(?,?,?,?)', [$project, $section, $name, $key]);
        return (int) $db->lastInsertId();
    });
}

function projectList(PDO $db): array
{
    return $db->query("SELECT p.*, COUNT(e.id) AS total,
        COALESCE((SELECT a.id FROM entries a
         WHERE a.project_id=p.id AND a.id=CAST(p.cover AS INTEGER) AND a.section='artwork'
         AND a.mime IN ('image/jpeg','image/png','image/webp','image/gif')),
         (SELECT a.id FROM entries a
         WHERE a.project_id=p.id AND a.section='artwork'
         AND a.mime IN ('image/jpeg','image/png','image/webp','image/gif')
         ORDER BY a.id DESC LIMIT 1)) AS cover_entry_id,
        SUM(CASE WHEN e.status='Completato' THEN 1 ELSE 0 END) AS done
        FROM projects p LEFT JOIN entries e ON e.project_id=p.id GROUP BY p.id ORDER BY p.id DESC")->fetchAll();
}

function value(array $data, string $key, int $limit, bool $required = false): string
{
    $raw = $data[$key] ?? '';
    if (!is_string($raw) || !preg_match('//u', $raw)) {
        throw new InputError('Controlla il formato dei campi.');
    }
    $text = trim($raw);
    if (mb_strlen($text) > $limit || ($required && $text === '')) {
        throw new InputError('Controlla i campi obbligatori e la lunghezza del testo.');
    }
    return $text;
}

function choice(string $candidate, array $allowed): string
{
    if (!in_array($candidate, $allowed, true)) {
        throw new InputError('Opzione non valida.');
    }
    return $candidate;
}

function saveEntry(PDO $db, int $project, array $body): int
{
    $id = (int) ($body['id'] ?? 0);
    $section = choice(value($body, 'section', 30), array_keys(SECTIONS));
    $url = value($body, 'url', 2000);
    if ($url !== '' && (!filter_var($url, FILTER_VALIDATE_URL) || !preg_match('~^https?://~i', $url))) {
        throw new InputError('Inserisci un link HTTP o HTTPS valido.');
    }
    $fields = [$section, value($body, 'title', 100, true), value($body, 'notes', 4000),
        choice(value($body, 'status', 20), STATUSES), $url];
    $approval = array_key_exists('approval', $body)
        ? choice(value($body, 'approval', 20), array_keys(APPROVALS)) : null;
    $relative = str_replace('\\', '/', value($body, 'local_file', 1024));
    $upload = $_FILES['attachment'] ?? ['error' => UPLOAD_ERR_NO_FILE];
    $file = null;
    if ($upload['error'] !== UPLOAD_ERR_NO_FILE) {
        if ($relative !== '') {
            throw new InputError('Scegli tra collegare un file e caricarne una copia.');
        }
        if ($upload['error'] !== UPLOAD_ERR_OK || $upload['size'] > 20 * 1024 * 1024 || !is_uploaded_file($upload['tmp_name'])) {
            throw new InputError('Carica un file fino a 20 MB.');
        }
        $name = basename(str_replace('\\', '/', $upload['name']));
        $name = preg_replace('/[\x00-\x1f\x7f]/u', '', mb_substr($name, 0, 180));
        $file = [$name ?: 'allegato', (new finfo(FILEINFO_MIME_TYPE))->file($upload['tmp_name']),
            file_get_contents($upload['tmp_name'])];
    }
    return atomic($db, function () use ($db, $project, $id, $section, $body, $fields, $file, $relative, $approval): int {
        $root = $relative === '' ? null : getProject($db, $project)['folder_path'];
        $original = $root === null ? null : linkedAttachmentPath($root, $relative);
        if ($relative !== '' && ($original === null || !is_readable($original))) {
            throw new InputError('Indica un file esistente con un percorso relativo alla cartella del progetto.');
        }
        $existing = $id ? query($db, 'SELECT section,category_id,approval FROM entries WHERE id=? AND project_id=?', [$id, $project])->fetch() : null;
        if ($id && !$existing) {
            throw new InputError('Voce non trovata.');
        }
        $category = $existing && $existing['section'] === $section ? $existing['category_id'] : null;
        if (array_key_exists('category_id', $body)) {
            $candidate = $body['category_id'];
            if ($candidate !== null && !is_int($candidate) && !is_string($candidate)) {
                throw new InputError('Scegli una categoria della sezione selezionata.');
            }
            $category = $candidate === '' || $candidate === null
                ? null : filter_var($candidate, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
            if ($category === false || ($category !== null && !query($db,
                'SELECT id FROM categories WHERE id=? AND project_id=? AND section=?', [$category, $project, $section])->fetchColumn())) {
                throw new InputError('Scegli una categoria della sezione selezionata.');
            }
        }
        $fields[] = $category;
        $fields[] = $approval ?? ($file || $original !== null ? 'review' : ($existing['approval'] ?? 'review'));
        if ($id) {
            $fields[] = $id;
            $fields[] = $project;
            query($db, 'UPDATE entries SET section=?,title=?,notes=?,status=?,url=?,category_id=?,approval=? WHERE id=? AND project_id=?', $fields);
        } else {
            query($db, 'INSERT INTO entries(project_id,section,title,notes,status,url,category_id,approval) VALUES(?,?,?,?,?,?,?,?)',
                [$project, ...$fields]);
            $id = (int) $db->lastInsertId();
        }
        if ($file) {
            query($db, 'DELETE FROM linked_attachments WHERE entry_id=? AND EXISTS
                (SELECT 1 FROM entries WHERE id=? AND project_id=?)', [$id, $id, $project]);
            $statement = $db->prepare('UPDATE entries SET filename=?,mime=?,attachment=? WHERE id=? AND project_id=?');
            $statement->bindValue(1, $file[0]);
            $statement->bindValue(2, $file[1]);
            $statement->bindValue(3, $file[2], PDO::PARAM_LOB);
            $statement->bindValue(4, $id, PDO::PARAM_INT);
            $statement->bindValue(5, $project, PDO::PARAM_INT);
            $statement->execute();
        }
        if ($original !== null) {
            $mime = (new finfo(FILEINFO_MIME_TYPE))->file($original) ?: 'application/octet-stream';
            query($db, 'UPDATE entries SET filename=?,mime=?,attachment=NULL WHERE id=? AND project_id=?',
                [basename($relative), $mime, $id, $project]);
            query($db, 'INSERT INTO linked_attachments(entry_id,root,relative_path) VALUES(?,?,?)
                ON CONFLICT(entry_id) DO UPDATE SET root=excluded.root,relative_path=excluded.relative_path', [$id, $root, $relative]);
        }
        return $id;
    });
}
