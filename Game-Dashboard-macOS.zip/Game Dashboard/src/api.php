<?php
declare(strict_types=1);

function reply(mixed $data, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE);
    exit;
}

function serveAttachment(PDO $db, int $project, int $id): never
{
    $file = query($db, 'SELECT e.filename,e.mime,e.attachment,a.root,a.relative_path
        FROM entries e LEFT JOIN linked_attachments a ON a.entry_id=e.id
        WHERE e.id=? AND e.project_id=?',
        [$id, $project])->fetch();
    if (!$file || $file['filename'] === null) {
        reply(['error' => 'Allegato non trovato.'], 404);
    }
    $stream = null;
    if ($file['root'] !== null) {
        $path = linkedAttachmentPath($file['root'], $file['relative_path']);
        $stream = $path === null ? false : @fopen($path, 'rb');
        if ($stream === false) {
            reply(['error' => 'Originale non disponibile.'], 404);
        }
    }
    $inline = in_array($file['mime'], ['image/jpeg', 'image/png', 'image/webp', 'image/gif'], true)
        && ($_GET['mode'] ?? '') === 'preview';
    header('Content-Type: ' . ($inline ? $file['mime'] : 'application/octet-stream'));
    header("Content-Disposition: " . ($inline ? "inline" : "attachment") . "; filename*=UTF-8''" . rawurlencode($file['filename']));
    if ($stream) {
        fpassthru($stream);
        fclose($stream);
    } else {
        echo $file['attachment'];
    }
    exit;
}

function mcpConfig(): array
{
    $root = dirname(__DIR__);
    $bundled = realpath($root . '/runtime/php/php.exe');
    $binary = realpath(PHP_BINARY);
    $args = [];
    if ($bundled !== false && $binary !== false && strcasecmp($bundled, $binary) === 0) {
        $runtime = dirname($bundled);
        $args = ['-c', $runtime . '/php.ini', '-d', 'extension_dir=' . $runtime . '/ext'];
    }
    $args[] = $root . '/mcp.php';
    return ['command' => PHP_BINARY, 'args' => $args];
}

function handleApi(string $action, string $csrf): never
{
    $method = $_SERVER['REQUEST_METHOD'];
    if (!in_array($method, ['GET', 'POST'], true)) {
        reply(['error' => 'Metodo non consentito.'], 405);
    }
    $body = [];
    if ($method === 'POST') {
        if (!hash_equals($csrf, $_SERVER['HTTP_X_WORKFLOW_CSRF'] ?? '')
            || ($_SERVER['HTTP_ORIGIN'] ?? '') !== 'http://' . $_SERVER['HTTP_HOST']) {
            reply(['error' => 'Ricarica la dashboard e riprova.'], 403);
        }
        $body = str_starts_with($_SERVER['CONTENT_TYPE'] ?? '', 'multipart/form-data')
            ? $_POST : json_decode(file_get_contents('php://input', false, null, 0, 65536), true);
        if (!is_array($body) || !$body && (int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > 24 * 1024 * 1024) {
            reply(['error' => 'Richiesta non valida o troppo grande.'], 400);
        }
    }
    session_write_close();
    try {
        $db = database();
        $id = (int) ($_GET['project'] ?? 0);
        if ($method === 'GET' && $action === 'file') {
            serveAttachment($db, $id, (int) ($_GET['id'] ?? 0));
        }
        if ($method === 'GET') {
            $data = match ($action) {
                'state' => ['projects' => projectList($db), 'sections' => SECTIONS, 'phases' => PHASES,
                    'statuses' => STATUSES, 'approvals' => APPROVALS],
                'project' => ['project' => getProject($db, $id), 'entries' => projectEntries($db, $id),
                    'categories' => projectCategories($db, $id)],
                'mcp' => mcpConfig(),
                default => throw new InputError('Azione sconosciuta.'),
            };
            reply($data);
        }
        $project = (int) ($body['project'] ?? 0);
        $record = (int) ($body['id'] ?? 0);
        if ($action === 'save-project') {
            reply(saveProject($db, $project, $body));
        }
        $game = getProject($db, $project);
        if ($action === 'archive') {
            query($db, 'UPDATE projects SET archived=? WHERE id=?', [$game['archived'] ? 0 : 1, $project]);
            reply(['ok' => true]);
        }
        if ($game['archived']) {
            throw new InputError('Ripristina il progetto per modificarlo.');
        }
        switch ($action) {
            case 'save-category':
                reply(['id' => saveCategory($db, $project, $body)]);
            case 'remove-category':
                $category = $body['id'] ?? null;
                $section = choice(value($body, 'section', 30), array_keys(SECTIONS));
                if (!is_int($category) || $category < 1) {
                    throw new InputError('Categoria non valida.');
                }
                $removed = query($db, 'DELETE FROM categories WHERE id=? AND project_id=? AND section=?
                    AND project_id IN (SELECT id FROM projects WHERE archived=0)', [$category, $project, $section])->rowCount();
                if (!$removed) {
                    throw new InputError('Categoria non trovata.');
                }
                reply(['ok' => true]);
            case 'save-entry':
                reply(['id' => saveEntry($db, $project, $body)]);
            case 'remove-entry':
                query($db, 'DELETE FROM entries WHERE id=? AND project_id=?', [$record, $project]);
                reply(['ok' => true]);
            default:
                throw new InputError('Azione sconosciuta.');
        }
    } catch (InputError $e) {
        reply(['error' => $e->getMessage()], 422);
    } catch (Throwable) {
        reply(['error' => 'Operazione non riuscita. Controlla che il server e la cartella dati siano disponibili.'], 500);
    }
}
