<?php
declare(strict_types=1);

function contextProject(PDO $db, int $id): array
{
    $project = getProject($db, $id);
    if ($project['archived']) {
        throw new InputError('Progetto archiviato.');
    }
    return $project;
}

function contextEntries(PDO $db, int $project, ?string $section, int $limit, int $offset): array
{
    $sql = 'SELECT e.id,e.section,e.title,e.status,e.approval,e.filename,substr(e.notes,1,450) AS notes,c.name AS category
        FROM entries e LEFT JOIN categories c ON c.id=e.category_id WHERE e.project_id=?';
    $params = [$project];
    if ($section !== null) {
        $sql .= ' AND e.section=?';
        $params[] = $section;
    }
    $sql .= ' ORDER BY e.id DESC LIMIT ? OFFSET ?';
    return query($db, $sql, [...$params, $limit, $offset])->fetchAll();
}

function readProjectContext(PDO $db, int $id, ?string $section = null, int $offset = 0, ?int $ifRevision = null): array
{
    $db->beginTransaction();
    try {
        $project = contextProject($db, $id);
        $revision = (int) $project['revision'];
        $result = ['project_id' => $id, 'revision' => $revision, 'unchanged' => $revision === $ifRevision];
        if (!$result['unchanged']) {
            $entries = contextEntries($db, $id, $section, 41, $offset);
            $more = count($entries) > 40;
            $result += ['project' => $project, 'sections' => SECTIONS, 'entries' => array_slice($entries, 0, 40),
                'more_entries' => $more, 'next_offset' => $more ? $offset + 40 : null];
        }
        $db->commit();
        return $result;
    } catch (Throwable $e) {
        $db->rollBack();
        throw $e;
    }
}
