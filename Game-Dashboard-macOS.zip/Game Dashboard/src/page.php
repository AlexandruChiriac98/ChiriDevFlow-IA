<?php
$icons = [
    'game' => '<path d="M7 7h10a4 4 0 0 1 4 3.4l.8 4.2a2.6 2.6 0 0 1-4.3 2.4L15 15H9l-2.5 2a2.6 2.6 0 0 1-4.3-2.4l.8-4.2A4 4 0 0 1 7 7Z"/><path d="M7 9.5v4m-2-2h4m6.8-.8h.1m2.4 2.1h.1"/>',
    'grid' => '<rect x="3" y="3" width="7" height="7" rx="1.1"/><rect x="14" y="3" width="7" height="7" rx="1.1"/><rect x="3" y="14" width="7" height="7" rx="1.1"/><rect x="14" y="14" width="7" height="7" rx="1.1"/>',
    'folder' => '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2Z"/>',
    'flow' => '<rect x="3" y="3" width="6" height="6" rx="1"/><rect x="15" y="15" width="6" height="6" rx="1"/><path d="M6 9v7a2 2 0 0 0 2 2h7m0-12h6m-3-3v6"/>',
    'plug' => '<path d="M9 3v5m6-5v5M7 8h10v3a5 5 0 0 1-10 0V8Zm5 8v5M5 8h14"/>',
    'image' => '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="8.3" cy="9" r="1.4"/><path d="m21 16-5-5-5 5-2-2-6 5"/>',
    'cube' => '<path d="m12 3 8.5 4.7v8.6L12 21l-8.5-4.7V7.7L12 3Zm0 9v9m-8-13 8 4 8-4"/>',
    'film' => '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 4v16M17 4v16M3 9h4m-4 6h4m10-6h4m-4 6h4"/>',
    'bolt' => '<path d="m13 2-9 12h7l-1 8 10-12h-7l1-8Z"/>',
    'book' => '<path d="M12 6v14M3 4h4a5 5 0 0 1 5 3 5 5 0 0 1 5-3h4v14h-4a6 6 0 0 0-5 2 6 6 0 0 0-5-2H3Z"/>',
    'file' => '<path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9Zm0 0v6h6M8 13h8m-8 4h6"/>',
    'check' => '<circle cx="12" cy="12" r="9"/><path d="m8 12 2.5 2.5L16 9"/>',
    'clock' => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    'plus' => '<path d="M12 5v14M5 12h14"/>',
    'search' => '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4 4"/>',
    'next' => '<path d="m9 6 6 6-6 6"/>',
    'back' => '<path d="m15 6-6 6 6 6"/>',
    'menu' => '<path d="M4 6h16M4 12h16M4 18h16"/>',
    'close' => '<path d="m6 6 12 12M18 6 6 18"/>',
    'trash' => '<path d="M4 7h16M9 7V4h6v3m3 0-.8 13H6.8L6 7m4 4v5m4-5v5"/>',
    'edit' => '<path d="m4 16 11-11 4 4L8 20H4v-4Zm9-9 4 4m-1-7 1-1 4 4-1 1"/>',
    'copy' => '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>',
];
?>
<!doctype html>
<html lang="it">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="workflow-csrf" content="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
    <title>Game Dashboard · IlChiriDev</title>
    <link rel="icon" href="/favicon.ico" sizes="16x16 32x32 48x48 64x64">
    <link rel="stylesheet" href="/css/tokens.css">
    <link rel="stylesheet" href="/css/base.css">
    <link rel="stylesheet" href="/css/components.css">
    <link rel="stylesheet" href="/css/pages.css">
    <script type="module" src="/js/app.js"></script>
</head>
<body>
    <svg class="symbols" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
        <?php foreach ($icons as $name => $drawing): ?>
            <symbol id="i-<?= $name ?>" viewBox="0 0 24 24"><?= $drawing ?></symbol>
        <?php endforeach ?>
    </svg>
    <a class="skip" href="#content">Salta al contenuto</a>
    <aside class="sidebar" id="sidebar">
        <a class="brand" href="#overview">
            <img class="brand-mark" src="/media/ilchiridev-icon.png" width="41" height="41" alt="">
            <span><strong>ILCHIRI<span>DEV</span></strong><small>Game Dashboard</small></span>
        </a>
        <nav id="nav" aria-label="Navigazione principale"></nav>
        <footer class="sidebar-footer"><span class="local-dot"></span><span>Workspace locale</span><small>v0.1</small></footer>
    </aside>
    <div class="shell">
        <header class="topbar">
            <button type="button" id="mobile-menu" class="icon-button mobile-menu" aria-label="Menu" aria-controls="sidebar" aria-expanded="false"><svg class="icon" aria-hidden="true"><use href="#i-menu"/></svg></button>
            <div class="crumb" id="crumb">Panoramica</div>
            <div class="top-actions">
                <button type="button" class="button search-button" aria-label="Cerca progetti" data-action="search"><svg class="icon" aria-hidden="true"><use href="#i-search"/></svg><span>Cerca progetti</span><kbd>/</kbd></button>
                <button type="button" class="button primary" aria-label="Nuovo progetto" data-action="new-project"><svg class="icon" aria-hidden="true"><use href="#i-plus"/></svg><span class="desktop-label">Nuovo progetto</span><span class="mobile-label" aria-hidden="true">Nuovo</span></button>
            </div>
        </header>
        <main id="content" tabindex="-1"><p class="loading">Caricamento della dashboard…</p></main>
    </div>
    <dialog id="dialog"><div id="dialog-body"></div></dialog>
    <div id="notice" role="status" aria-live="polite"></div>
</body>
</html>
